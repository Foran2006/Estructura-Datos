package com.ecorutas;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import com.ecorutas.estructuras.*;
import com.ecorutas.modelos.*;
import com.ecorutas.servicios.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Sistema ECORUTAS con interfaz mejorada
 * Menús con opciones numeradas visibles (sin ComboBox)
 */
public class SistemaEcorutas {
    private ListaEnlazada<Cliente> clientes;
    private ListaEnlazada<PaqueteTuristico> paquetes;
    private ListaEnlazada<ServicioAdicional> servicios;
    private Cola<String> colaAtencion;
    private Pila<String> historialServicios;
    private GestorReservas gestorReservas;
    private GestorPagos gestorPagos;
    private GestorEstadisticas gestorEstadisticas;

    public SistemaEcorutas() {
        clientes = new ListaEnlazada<>();
        paquetes = new ListaEnlazada<>();
        servicios = new ListaEnlazada<>();
        colaAtencion = new Cola<>();
        historialServicios = new Pila<>();
        
        gestorReservas = new GestorReservas();
        gestorReservas.setClientes(clientes);
        gestorReservas.setPaquetes(paquetes);
        
        gestorPagos = new GestorPagos();
        
        gestorEstadisticas = new GestorEstadisticas(gestorReservas, gestorPagos);
        
        inicializarServiciosBasicos();
        cargarDatosPrueba();
    }

    // ==================== MENÚ PRINCIPAL ====================
    
    public void mostrarMenuPrincipal() {
        while (true) {
            String menu = 
                "=================================================\n" +
                "        SISTEMA DE GESTIÓN ECORUTAS              \n" +
                "              Agencia de Viajes                   \n" +
                "=================================================\n\n" +
                "  1. Gestión de Clientes\n" +
                "  2. Gestión de Paquetes Turísticos\n" +
                "  3. Gestión de Reservas\n" +
                "  4. Gestión de Servicios Adicionales\n" +
                "  5. Cola de Atención\n" +
                "  6. Reportes y Estadísticas\n" +
                "  7. Salir\n\n" +
                "Ingrese el número de opción:";

            String opcion = JOptionPane.showInputDialog(null, menu, "Menú Principal", 
                JOptionPane.PLAIN_MESSAGE);

            if (opcion == null || opcion.trim().equals("7")) {
                if (confirmarSalida()) break;
                continue;
            }

            try {
                switch (opcion.trim()) {
                    case "1": mostrarMenuClientes(); break;
                    case "2": mostrarMenuPaquetes(); break;
                    case "3": mostrarMenuReservas(); break;
                    case "4": mostrarMenuServicios(); break;
                    case "5": gestionarColaAtencion(); break;
                    case "6": mostrarMenuReportes(); break;
                    default: mostrarError("Opción Inválida", "Por favor ingrese un número del 1 al 7");
                }
            } catch (Exception e) {
                mostrarError("Error en la operación", e.getMessage());
            }
        }
    }

    // ==================== MENÚ CLIENTES ====================
    
    private void mostrarMenuClientes() {
        while (true) {
            String menu = 
                "=================================================\n" +
                "              GESTIÓN DE CLIENTES                \n" +
                "=================================================\n\n" +
                "  1. Registrar Nuevo Cliente\n" +
                "  2. Buscar Cliente\n" +
                "  3. Modificar Cliente\n" +
                "  4. Eliminar Cliente\n" +
                "  5. Listar Todos los Clientes\n" +
                "  6. Volver al Menú Principal\n\n" +
                String.format("Clientes registrados: %d\n\n", clientes.getTamanio()) +
                "Ingrese el número de opción:";

            String opcion = JOptionPane.showInputDialog(null, menu, "Menú Clientes",
                JOptionPane.PLAIN_MESSAGE);

            if (opcion == null || opcion.trim().equals("6")) break;

            try {
                switch (opcion.trim()) {
                    case "1": registrarNuevoCliente(); break;
                    case "2": buscarCliente(); break;
                    case "3": modificarCliente(); break;
                    case "4": eliminarCliente(); break;
                    case "5": listarClientes(); break;
                    default: mostrarError("Opción Inválida", "Ingrese un número del 1 al 6");
                }
            } catch (Exception e) {
                mostrarError("Error en gestión de clientes", e.getMessage());
            }
        }
    }

    private void registrarNuevoCliente() {
        try {
            String documento = JOptionPane.showInputDialog("Ingrese el documento del cliente:");
            if (documento == null || documento.trim().isEmpty()) {
                mostrarError("Error", "El documento no puede estar vacío");
                return;
            }
            documento = documento.trim();

            Cliente clienteTemp = new Cliente(documento);
            if (clientes.buscar(clienteTemp) != null) {
                mostrarError("Error", "Ya existe un cliente con ese documento");
                return;
            }

            String nombre = JOptionPane.showInputDialog("Ingrese el nombre completo:");
            if (nombre == null || nombre.trim().isEmpty()) {
                mostrarError("Error", "El nombre no puede estar vacío");
                return;
            }
            nombre = nombre.trim();

            String edadStr = JOptionPane.showInputDialog("Ingrese la edad:");
            if (edadStr == null) return;
            int edad = Integer.parseInt(edadStr);

            String menuGenero = 
                "Seleccione el género:\n\n" +
                "  1. Masculino\n" +
                "  2. Femenino\n" +
                "  3. Otro\n\n" +
                "Ingrese el número:";
            String generoOp = JOptionPane.showInputDialog(menuGenero);
            if (generoOp == null) return;
            
            String genero;
            switch (generoOp.trim()) {
                case "1": genero = "Masculino"; break;
                case "2": genero = "Femenino"; break;
                case "3": genero = "Otro"; break;
                default: mostrarError("Error", "Opción inválida"); return;
            }

            String telefono = JOptionPane.showInputDialog("Ingrese el teléfono:");
            if (telefono == null || telefono.trim().isEmpty()) {
                mostrarError("Error", "El teléfono no puede estar vacío");
                return;
            }
            telefono = telefono.trim();

            String correo = JOptionPane.showInputDialog("Ingrese el correo electrónico:");
            if (correo == null || correo.trim().isEmpty()) {
                mostrarError("Error", "El correo no puede estar vacío");
                return;
            }
            correo = correo.trim();

            String menuTipo = 
                "Seleccione el tipo de cliente:\n\n" +
                "  1. Particular\n" +
                "  2. Empresa\n\n" +
                "Ingrese el número:";
            String tipoOp = JOptionPane.showInputDialog(menuTipo);
            if (tipoOp == null) return;
            
            String tipoCliente;
            switch (tipoOp.trim()) {
                case "1": tipoCliente = "Particular"; break;
                case "2": tipoCliente = "Empresa"; break;
                default: mostrarError("Error", "Opción inválida"); return;
            }

            Cliente nuevoCliente = new Cliente(documento, nombre, edad, genero, telefono, correo, tipoCliente);
            clientes.agregar(nuevoCliente);
            
            mostrarExito("Cliente Registrado", 
                "✓ Cliente registrado exitosamente\n\n" + nuevoCliente.toString());

        } catch (NumberFormatException e) {
            mostrarError("Error", "La edad debe ser un número válido");
        } catch (IllegalArgumentException e) {
            mostrarError("Error de validación", e.getMessage());
        }
    }

    private void buscarCliente() {
        String documento = JOptionPane.showInputDialog("Ingrese el documento del cliente:");
        if (documento == null || documento.trim().isEmpty()) return;

        Cliente clienteTemp = new Cliente(documento);
        Cliente cliente = clientes.buscar(clienteTemp);

        if (cliente != null) {
            int reservasCount = gestorReservas.contarReservasCliente(cliente);
            double gastoTotal = gestorReservas.calcularGastoTotalCliente(cliente);
            
            String info = String.format(
                "================================================\n" +
                "           INFORMACIÓN DEL CLIENTE                     \n" +
                "================================================\n\n" +
                "Documento:    %s\n" +
                "Nombre:       %s\n" +
                "Edad:         %d años (%s)\n" +
                "Género:       %s\n" +
                "Teléfono:     %s\n" +
                "Correo:       %s\n" +
                "Tipo:         %s\n\n" +
                "================================================\n" +
                "ESTADÍSTICAS\n" +
                "================================================\n\n" +
                "  • Reservas realizadas:  %d\n" +
                "  • Gasto total:          $%,.2f\n" +
                "  • Cliente frecuente:    %s\n",
                cliente.getDocumento(), cliente.getNombre(), cliente.getEdad(),
                cliente.getRangoEdad(), cliente.getGenero(), cliente.getTelefono(),
                cliente.getCorreo(), cliente.getTipoCliente(), reservasCount,
                gastoTotal, (reservasCount > 2 ? "SÍ" : "NO")
            );
            
            JOptionPane.showMessageDialog(null, info, "Cliente Encontrado", 
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            mostrarAdvertencia("No Encontrado", 
                "No existe un cliente con el documento: " + documento);
        }
    }

    private void modificarCliente() {
        String documento = JOptionPane.showInputDialog("Ingrese el documento del cliente:");
        if (documento == null || documento.trim().isEmpty()) return;

        Cliente clienteTemp = new Cliente(documento);
        Cliente cliente = clientes.buscar(clienteTemp);

        if (cliente == null) {
            mostrarAdvertencia("No Encontrado", "Cliente no existe");
            return;
        }

        while (true) {
            String menu = String.format(
                "=================================================\n" +
                "           MODIFICAR CLIENTE                           \n" +
                "=================================================\n\n" +
                "Cliente: %s (Doc: %s)\n" +
                "Edad: %d | Tel: %s\n" +
                "Correo: %s\n\n" +
                "-------------------------------------------------\n\n" +
                "  1. Modificar Nombre\n" +
                "  2. Modificar Edad\n" +
                "  3. Modificar Teléfono\n" +
                "  4. Modificar Correo\n" +
                "  5. Volver\n\n" +
                "Ingrese el número de opción:",
                cliente.getNombre(), cliente.getDocumento(),
                cliente.getEdad(), cliente.getTelefono(), cliente.getCorreo()
            );

            String opcion = JOptionPane.showInputDialog(menu);
            if (opcion == null || opcion.trim().equals("5")) break;

            try {
                switch (opcion.trim()) {
                    case "1":
                        String nombre = JOptionPane.showInputDialog("Nuevo Nombre:", cliente.getNombre());
                        if (nombre != null && !nombre.trim().isEmpty()) {
                            cliente.setNombre(nombre);
                            mostrarExito("Éxito", "✓ Nombre actualizado");
                        }
                        break;
                    case "2":
                        String edadStr = JOptionPane.showInputDialog("Nueva Edad:", cliente.getEdad());
                        if (edadStr != null) {
                            cliente.setEdad(Integer.parseInt(edadStr.trim()));
                            mostrarExito("Éxito", "✓ Edad actualizada");
                        }
                        break;
                    case "3":
                        String telefono = JOptionPane.showInputDialog("Nuevo Teléfono:", cliente.getTelefono());
                        if (telefono != null && !telefono.trim().isEmpty()) {
                            cliente.setTelefono(telefono);
                            mostrarExito("Éxito", "✓ Teléfono actualizado");
                        }
                        break;
                    case "4":
                        String correo = JOptionPane.showInputDialog("Nuevo Correo:", cliente.getCorreo());
                        if (correo != null && !correo.trim().isEmpty()) {
                            cliente.setCorreo(correo);
                            mostrarExito("Éxito", "✓ Correo actualizado");
                        }
                        break;
                    default:
                        mostrarError("Opción Inválida", "Ingrese un número del 1 al 5");
                }
            } catch (NumberFormatException e) {
                mostrarError("Error", "La edad debe ser un número válido");
            } catch (IllegalArgumentException e) {
                mostrarError("Error de validación", e.getMessage());
            }
        }
    }

    private void eliminarCliente() {
        String documento = JOptionPane.showInputDialog("Ingrese el documento del cliente:");
        if (documento == null || documento.trim().isEmpty()) return;

        Cliente clienteTemp = new Cliente(documento);
        Cliente cliente = clientes.buscar(clienteTemp);

        if (cliente != null) {
            int reservasActivas = gestorReservas.buscarReservasPorCliente(cliente)
                .contar(r -> r.getEstado().equals("confirmada") || r.getEstado().equals("pendiente"));
            
            if (reservasActivas > 0) {
                mostrarError("No se puede eliminar", 
                    "El cliente tiene " + reservasActivas + " reservas activas");
                return;
            }

            int conf = JOptionPane.showConfirmDialog(null,
                "¿Está seguro de eliminar al cliente?\n\n" + cliente.toString(),
                "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);

            if (conf == JOptionPane.YES_OPTION) {
                clientes.eliminar(clienteTemp);
                mostrarExito("Éxito", "✓ Cliente eliminado correctamente");
            }
        } else {
            mostrarAdvertencia("No Encontrado", "Cliente no existe");
        }
    }

    private void listarClientes() {
        if (clientes.estaVacia()) {
            mostrarAdvertencia("Lista Vacía", "No hay clientes registrados");
            return;
        }

        StringBuilder lista = new StringBuilder();
        lista.append("=================================================\n");
        lista.append("              LISTADO DE CLIENTES                      \n");
        lista.append("=================================================\n\n");

        final int[] contador = {1};
        clientes.paraCadaElemento(cliente -> {
            lista.append(String.format("%d. %s - %s\n", 
                contador[0]++, cliente.getNombre(), cliente.getDocumento()));
            lista.append(String.format("   Edad: %d | Género: %s | Tipo: %s\n",
                cliente.getEdad(), cliente.getGenero(), cliente.getTipoCliente()));
            lista.append(String.format("   Tel: %s | Email: %s\n\n",
                cliente.getTelefono(), cliente.getCorreo()));
        });

        lista.append("====================================================\n");
        lista.append(String.format("Total de clientes: %d\n", clientes.getTamanio()));

        JOptionPane.showMessageDialog(null, lista.toString(), 
            "Lista de Clientes", JOptionPane.INFORMATION_MESSAGE);
    }

    // ==================== MENÚ PAQUETES ====================
    
    private void mostrarMenuPaquetes() {
        while (true) {
            String menu = 
                "=================================================\n" +
                "         GESTIÓN DE PAQUETES TURÍSTICOS                \n" +
                "=================================================\n\n" +
                "  1. Registrar Nuevo Paquete\n" +
                "  2. Buscar Paquete\n" +
                "  3. Modificar Paquete\n" +
                "  4. Eliminar Paquete\n" +
                "  5. Listar Todos los Paquetes\n" +
                "  6. Ver Ocupación de Paquetes\n" +
                "  7. Volver al Menú Principal\n\n" +
                String.format("Paquetes registrados: %d\n\n", paquetes.getTamanio()) +
                "Ingrese el número de opción:";

            String opcion = JOptionPane.showInputDialog(null, menu, "Menú Paquetes",
                JOptionPane.PLAIN_MESSAGE);

            if (opcion == null || opcion.trim().equals("7")) break;

            try {
                switch (opcion.trim()) {
                    case "1": registrarNuevoPaquete(); break;
                    case "2": buscarPaquete(); break;
                    case "3": modificarPaquete(); break;
                    case "4": eliminarPaquete(); break;
                    case "5": listarPaquetes(); break;
                    case "6": verOcupacionPaquetes(); break;
                    default: mostrarError("Opción Inválida", "Ingrese un número del 1 al 7");
                }
            } catch (Exception e) {
                mostrarError("Error", e.getMessage());
            }
        }
    }

    private void registrarNuevoPaquete() {
        try {
            String codigo = JOptionPane.showInputDialog("Código del paquete:");
            if (codigo == null || codigo.trim().isEmpty()) return;

            PaqueteTuristico temp = new PaqueteTuristico(codigo);
            if (paquetes.buscar(temp) != null) {
                mostrarError("Error", "Ya existe un paquete con ese código");
                return;
            }

            String destino = JOptionPane.showInputDialog("Destino:");
            if (destino == null || destino.trim().isEmpty()) return;

            int duracion = Integer.parseInt(JOptionPane.showInputDialog("Duración (días):"));

            String menuTipo = 
                "Seleccione el tipo de paquete:\n\n" +
                "  1. Nacional\n" +
                "  2. Internacional\n\n" +
                "Ingrese el número:";
            String tipoOp = JOptionPane.showInputDialog(menuTipo);
            if (tipoOp == null) return;
            
            String tipo;
            switch (tipoOp.trim()) {
                case "1": tipo = "Nacional"; break;
                case "2": tipo = "Internacional"; break;
                default: mostrarError("Error", "Opción inválida"); return;
            }

            double precio = Double.parseDouble(JOptionPane.showInputDialog("Precio por persona:"));
            int plazas = Integer.parseInt(JOptionPane.showInputDialog("Total de plazas:"));

            PaqueteTuristico paquete = new PaqueteTuristico(codigo, destino, duracion, tipo, precio, plazas);
            paquetes.agregar(paquete);

            mostrarExito("Éxito", "✓ Paquete registrado exitosamente\n\n" + paquete.toString());
        } catch (NumberFormatException e) {
            mostrarError("Error", "Valores numéricos inválidos");
        }
    }

    private void buscarPaquete() {
        String codigo = JOptionPane.showInputDialog("Código del paquete:");
        if (codigo == null || codigo.trim().isEmpty()) return;

        PaqueteTuristico temp = new PaqueteTuristico(codigo);
        PaqueteTuristico paquete = paquetes.buscar(temp);

        if (paquete != null) {
            double montoVentas = gestorReservas.getMontoTotalPorPaquete(paquete);
            String info = String.format(
                "=================================================\n" +
                "          INFORMACIÓN DEL PAQUETE                      \n" +
                "=================================================\n\n" +
                "Código:       %s\n" +
                "Destino:      %s\n" +
                "Duración:     %d días\n" +
                "Tipo:         %s\n" +
                "Precio:       $%,.2f por persona\n\n" +
                "=================================================\n" +
                "DISPONIBILIDAD\n" +
                "=================================================\n\n" +
                "  • Plazas Totales:     %d\n" +
                "  • Plazas Ocupadas:    %d\n" +
                "  • Plazas Disponibles: %d\n" +
                "  • Ocupación:          %.1f%%\n\n" +
                "=================================================\n" +
                "VENTAS\n" +
                "=================================================\n\n" +
                "  • Monto Recaudado:    $%,.2f\n" +
                "  • Reservas:           %d\n",
                paquete.getCodigo(), paquete.getDestino(), paquete.getDuracionDias(),
                paquete.getTipo(), paquete.getPrecioPorPersona(),
                paquete.getPlazasTotales(), paquete.getPlazasOcupadas(),
                paquete.getPlazasDisponibles(), paquete.getPorcentajeOcupacion(),
                montoVentas, paquete.getTotalReservasRealizadas()
            );
            
            JOptionPane.showMessageDialog(null, info, "Paquete Encontrado", 
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            mostrarAdvertencia("No Encontrado", "No existe el paquete: " + codigo);
        }
    }

    private void modificarPaquete() {
        String codigo = JOptionPane.showInputDialog("Código del paquete:");
        if (codigo == null || codigo.trim().isEmpty()) return;

        PaqueteTuristico temp = new PaqueteTuristico(codigo);
        PaqueteTuristico paquete = paquetes.buscar(temp);

        if (paquete == null) {
            mostrarAdvertencia("No Encontrado", "Paquete no existe");
            return;
        }

        while (true) {
            String menu = String.format(
                "=================================================\n" +
                "           MODIFICAR PAQUETE                           \n" +
                "=================================================\n\n" +
                "Paquete: %s (%s)\n" +
                "Precio: $%,.2f | Plazas: %d/%d\n\n" +
                "-------------------------------------------------\n\n" +
                "  1. Modificar Destino\n" +
                "  2. Modificar Duración\n" +
                "  3. Modificar Precio\n" +
                "  4. Modificar Plazas Totales\n" +
                "  5. Volver\n\n" +
                "Ingrese el número de opción:",
                paquete.getDestino(), paquete.getCodigo(),
                paquete.getPrecioPorPersona(),
                paquete.getPlazasOcupadas(), paquete.getPlazasTotales()
            );

            String opcion = JOptionPane.showInputDialog(menu);
            if (opcion == null || opcion.trim().equals("5")) break;

            try {
                switch (opcion.trim()) {
                    case "1":
                        String destino = JOptionPane.showInputDialog("Nuevo Destino:", paquete.getDestino());
                        if (destino != null && !destino.trim().isEmpty()) {
                            paquete.setDestino(destino);
                            mostrarExito("Éxito", "✓ Destino actualizado");
                        }
                        break;
                    case "2":
                        String durStr = JOptionPane.showInputDialog("Nueva Duración (días):", paquete.getDuracionDias());
                        if (durStr != null) {
                            paquete.setDuracionDias(Integer.parseInt(durStr.trim()));
                            mostrarExito("Éxito", "✓ Duración actualizada");
                        }
                        break;
                    case "3":
                        String precioStr = JOptionPane.showInputDialog("Nuevo Precio:", paquete.getPrecioPorPersona());
                        if (precioStr != null) {
                            paquete.setPrecioPorPersona(Double.parseDouble(precioStr.trim()));
                            mostrarExito("Éxito", "✓ Precio actualizado");
                        }
                        break;
                    case "4":
                        String plazasStr = JOptionPane.showInputDialog("Nuevas Plazas Totales:", paquete.getPlazasTotales());
                        if (plazasStr != null) {
                            paquete.setPlazasTotales(Integer.parseInt(plazasStr.trim()));
                            mostrarExito("Éxito", "✓ Plazas actualizadas");
                        }
                        break;
                    default:
                        mostrarError("Opción Inválida", "Ingrese un número del 1 al 5");
                }
            } catch (NumberFormatException e) {
                mostrarError("Error", "Valor numérico inválido");
            } catch (IllegalArgumentException e) {
                mostrarError("Error de validación", e.getMessage());
            }
        }
    }

    private void eliminarPaquete() {
        String codigo = JOptionPane.showInputDialog("Código del paquete:");
        if (codigo == null || codigo.trim().isEmpty()) return;

        PaqueteTuristico temp = new PaqueteTuristico(codigo);
        PaqueteTuristico paquete = paquetes.buscar(temp);

        if (paquete != null) {
            int reservas = gestorReservas.buscarReservasPorPaquete(paquete).getTamanio();
            if (reservas > 0) {
                mostrarError("No se puede eliminar", "El paquete tiene " + reservas + " reservas");
                return;
            }

            int conf = JOptionPane.showConfirmDialog(null, "¿Eliminar paquete?\n\n" + paquete.toString(),
                "Confirmar", JOptionPane.YES_NO_OPTION);

            if (conf == JOptionPane.YES_OPTION) {
                paquetes.eliminar(temp);
                mostrarExito("Éxito", "✓ Paquete eliminado");
            }
        } else {
            mostrarAdvertencia("No Encontrado", "Paquete no existe");
        }
    }

    private void listarPaquetes() {
        if (paquetes.estaVacia()) {
            mostrarAdvertencia("Lista Vacía", "No hay paquetes registrados");
            return;
        }

        StringBuilder lista = new StringBuilder();
        lista.append("=================================================\n");
        lista.append("         LISTADO DE PAQUETES TURÍSTICOS                \n");
        lista.append("=================================================\n\n");

        final int[] contador = {1};
        paquetes.paraCadaElemento(paquete -> {
            lista.append(String.format("%d. %s - %s\n", contador[0]++, 
                paquete.getCodigo(), paquete.getDestino()));
            lista.append(String.format("   %d días | %s | $%,.0f\n",
                paquete.getDuracionDias(), paquete.getTipo(), paquete.getPrecioPorPersona()));
            lista.append(String.format("   Disponible: %d/%d plazas (%.0f%% ocupado)\n\n",
                paquete.getPlazasDisponibles(), paquete.getPlazasTotales(),
                paquete.getPorcentajeOcupacion()));
        });

        lista.append("===================================================\n");
        lista.append(String.format("Total de paquetes: %d\n", paquetes.getTamanio()));

        JOptionPane.showMessageDialog(null, lista.toString(), "Paquetes", 
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void verOcupacionPaquetes() {
        String reporte = gestorEstadisticas.generarReporteOcupacionPaquetes(paquetes);
        JOptionPane.showMessageDialog(null, reporte, "Ocupación de Paquetes",
            JOptionPane.INFORMATION_MESSAGE);
    }

    // ==================== MENÚ RESERVAS ====================
    
    private void mostrarMenuReservas() {
        while (true) {
            String menu = 
                "=================================================\n" +
                "              GESTIÓN DE RESERVAS                      \n" +
                "=================================================\n\n" +
                "  1. Crear Nueva Reserva\n" +
                "  2. Buscar Reserva\n" +
                "  3. Confirmar Reserva\n" +
                "  4. Cancelar Reserva\n" +
                "  5. Agregar Servicio a Reserva\n" +
                "  6. Listar Todas las Reservas\n" +
                "  7. Volver al Menú Principal\n\n" +
                String.format("Reservas totales: %d\n\n", gestorReservas.getTotalReservas()) +
                "Ingrese el número de opción:";

            String opcion = JOptionPane.showInputDialog(null, menu, "Menú Reservas",
                JOptionPane.PLAIN_MESSAGE);

            if (opcion == null || opcion.trim().equals("7")) break;

            try {
                switch (opcion.trim()) {
                    case "1": crearNuevaReserva(); break;
                    case "2": buscarReserva(); break;
                    case "3": confirmarReservaMenu(); break;
                    case "4": cancelarReservaMenu(); break;
                    case "5": agregarServicioReserva(); break;
                    case "6": listarReservas(); break;
                    default: mostrarError("Opción Inválida", "Ingrese un número del 1 al 7");
                }
            } catch (Exception e) {
                mostrarError("Error", e.getMessage());
            }
        }
    }

    private void crearNuevaReserva() {
        try {
            if (clientes.estaVacia()) {
                mostrarError("Error", "No hay clientes registrados");
                return;
            }

            String docCliente = JOptionPane.showInputDialog("Documento del cliente:");
            if (docCliente == null) return;

            Cliente clienteTemp = new Cliente(docCliente);
            Cliente cliente = clientes.buscar(clienteTemp);
            if (cliente == null) {
                mostrarError("Error", "Cliente no encontrado");
                return;
            }

            if (paquetes.estaVacia()) {
                mostrarError("Error", "No hay paquetes disponibles");
                return;
            }

            String codPaquete = JOptionPane.showInputDialog("Código del paquete:");
            if (codPaquete == null) return;

            PaqueteTuristico paqTemp = new PaqueteTuristico(codPaquete);
            PaqueteTuristico paquete = paquetes.buscar(paqTemp);
            if (paquete == null) {
                mostrarError("Error", "Paquete no encontrado");
                return;
            }

            int personas = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de personas:"));

            String menuMedio = 
                "Seleccione el medio de pago:\n\n" +
                "  1. Efectivo\n" +
                "  2. Débito\n" +
                "  3. Crédito\n" +
                "  4. Transferencia\n\n" +
                "Ingrese el número:";
            String medioOp = JOptionPane.showInputDialog(menuMedio);
            if (medioOp == null) return;
            
            String medio;
            switch (medioOp.trim()) {
                case "1": medio = "Efectivo"; break;
                case "2": medio = "Debito"; break;
                case "3": medio = "Credito"; break;
                case "4": medio = "Transferencia"; break;
                default: mostrarError("Error", "Opción inválida"); return;
            }

            int dias = Integer.parseInt(JOptionPane.showInputDialog(
                "Días hasta el viaje\n(para calcular descuento por anticipación):"));
            
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH, dias);
            Date fechaViaje = cal.getTime();

            Reserva reserva = gestorReservas.crearReserva(cliente, paquete, personas, medio, fechaViaje);
            
            mostrarExito("Reserva Creada", 
                String.format(
                    "=================================================\n" +
                    "          RESERVA CREADA EXITOSAMENTE                  \n" +
                    "=================================================\n\n" +
                    "Código:   %s\n" +
                    "Estado:   %s\n" +
                    "Monto:    $%,.2f\n\n" +
                    "-------------------------------------------------\n\n" +
                    "⚠ La reserva está PENDIENTE\n" +
                    "Use la opción 'Confirmar Reserva' para completarla.",
                    reserva.getCodigo(), reserva.getEstado().toUpperCase(), reserva.getMontoTotal()
                ));

        } catch (NumberFormatException e) {
            mostrarError("Error", "Valor numérico inválido");
        } catch (Exception e) {
            mostrarAdvertencia("Información", e.getMessage());
        }
    }

    private void buscarReserva() {
        String codigo = JOptionPane.showInputDialog("Código de reserva:");
        if (codigo == null) return;

        Reserva reserva = gestorReservas.buscarReserva(codigo);
        if (reserva != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            
            StringBuilder info = new StringBuilder();
            info.append("=================================================\n");
            info.append("          INFORMACIÓN DE LA RESERVA                    \n");
            info.append("=================================================\n\n");
            info.append(String.format("Código:          %s\n", reserva.getCodigo()));
            info.append(String.format("Estado:          %s\n\n", reserva.getEstado().toUpperCase()));
            info.append(String.format("Cliente:         %s\n", reserva.getCliente().getNombre()));
            info.append(String.format("Paquete:         %s\n", reserva.getPaquete().getDestino()));
            info.append(String.format("Personas:        %d\n", reserva.getCantidadPersonas()));
            info.append(String.format("Medio de Pago:   %s\n\n", reserva.getMedioPago()));
            info.append(String.format("Fecha Reserva:   %s\n", sdf.format(reserva.getFechaReserva())));
            
            if (reserva.getFechaViaje() != null) {
                info.append(String.format("Fecha Viaje:     %s\n", sdf.format(reserva.getFechaViaje())));
            }

            info.append("\n=================================================\n");
            info.append("DETALLE DE MONTOS\n");
            info.append("=================================================\n\n");
            info.append(String.format("  • Base:         $%,15.2f\n", reserva.getMontoBase()));
            info.append(String.format("  • Servicios:    $%,15.2f\n", reserva.getMontoServicios()));
            info.append(String.format("  • Descuentos:  -$%,15.2f\n", reserva.getMontoDescuentos()));
            info.append(String.format("  • Recargos:    +$%,15.2f\n", reserva.getMontoRecargos()));
            info.append("                  --------------------\n");
            info.append(String.format("  • TOTAL:        $%,15.2f\n", reserva.getMontoTotal()));

            JOptionPane.showMessageDialog(null, info.toString(), "Reserva",
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            mostrarAdvertencia("No Encontrada", "No existe la reserva: " + codigo);
        }
    }

    private void confirmarReservaMenu() {
        String codigo = JOptionPane.showInputDialog("Código de reserva a confirmar:");
        if (codigo == null) return;

        Reserva reserva = gestorReservas.buscarReserva(codigo);
        if (reserva == null) {
            mostrarError("Error", "Reserva no encontrada");
            return;
        }
        
        if (reserva.getEstado().equals("confirmada")) {
            mostrarAdvertencia("Información", "Esta reserva ya está confirmada");
            return;
        }

        boolean exito = gestorReservas.confirmarReserva(codigo);
        if (exito) {
            gestorPagos.registrarPago(reserva, reserva.getMedioPago(), reserva.getMontoTotal());
            mostrarExito("Éxito", 
                "=================================================\n" +
                "          RESERVA CONFIRMADA EXITOSAMENTE        \n" +
                "=================================================\n\n" +
                String.format("Código: %s\nMonto: $%,.2f", codigo, reserva.getMontoTotal()));
        } else {
            mostrarError("Error", "No se pudo confirmar la reserva\n(posiblemente falta de plazas)");
        }
    }

    private void cancelarReservaMenu() {
        String codigo = JOptionPane.showInputDialog("Código de reserva a cancelar:");
        if (codigo == null) return;

        Reserva reserva = gestorReservas.buscarReserva(codigo);
        if (reserva == null) {
            mostrarError("Error", "Reserva no encontrada");
            return;
        }
        
        if (reserva.getEstado().equals("cancelada")) {
            mostrarAdvertencia("Información", "Esta reserva ya estaba cancelada");
            return;
        }

        double penalidad = reserva.calcularPenalidadCancelacion();
        String mensaje = 
            "¿Está seguro de cancelar esta reserva?\n\n" +
            "Código:  " + codigo + "\n" +
            "Cliente: " + reserva.getCliente().getNombre() + "\n" +
            "Monto:   $" + String.format("%,.2f", reserva.getMontoTotal());

        if (penalidad > 0) {
            mensaje += "\n\n⚠ Se aplicará penalidad del 20%\nPenalidad: $" + 
                      String.format("%,.2f", penalidad);
        }

        int conf = JOptionPane.showConfirmDialog(null, mensaje, "Confirmar Cancelación",
            JOptionPane.YES_NO_OPTION);

        if (conf == JOptionPane.YES_OPTION) {
            gestorReservas.cancelarReserva(codigo);
            mostrarExito("Éxito", "✓ Reserva cancelada");
        }
    }

    private void agregarServicioReserva() {
        try {
            String codigo = JOptionPane.showInputDialog("Código de reserva:");
            if (codigo == null) return;

            Reserva reserva = gestorReservas.buscarReserva(codigo);
            if (reserva == null) {
                mostrarError("Error", "Reserva no encontrada");
                return;
            }

            String codServicio = JOptionPane.showInputDialog("Código del servicio:");
            if (codServicio == null) return;

            ServicioAdicional servicioTemp = new ServicioAdicional(codServicio);
            ServicioAdicional servicio = servicios.buscar(servicioTemp);

            if (servicio == null) {
                mostrarError("Error", "Servicio no encontrado");
                return;
            }

            // Asumimos que el servicio se agrega para todas las personas de la reserva
            gestorReservas.agregarServicioAdicional(codigo, servicio, reserva.getCantidadPersonas(), reserva.getCliente().getDocumento());
            historialServicios.push(servicio.getNombre());
            
            mostrarExito("Éxito", 
                String.format("✓ Servicio agregado correctamente\n\n" +
                "Servicio: %s\n" +
                "Precio: $%,.2f por persona\n" +
                "Nuevo total: $%,.2f",
                servicio.getNombre(), servicio.getPrecioPorPersona(),
                reserva.getMontoTotal()));

        } catch (Exception e) {
            mostrarError("Error", e.getMessage());
        }
    }

    private void listarReservas() {
        if (gestorReservas.getReservas().estaVacia()) {
            mostrarAdvertencia("Vacío", "No hay reservas registradas");
            return;
        }

        StringBuilder lista = new StringBuilder();
        lista.append("=================================================\n");
        lista.append("              LISTADO DE RESERVAS                      \n");
        lista.append("=================================================\n\n");

        final int[] cont = {1};
        gestorReservas.getReservas().paraCadaElemento(r -> {
            String estadoIcono = "";
            switch (r.getEstado().toLowerCase()) {
                case "confirmada": estadoIcono = "✓"; break;
                case "pendiente": estadoIcono = "⏳"; break;
                case "cancelada": estadoIcono = "✗"; break;
            }
            
            lista.append(String.format("%d. %s %s - %s\n", cont[0]++, estadoIcono,
                r.getCodigo(), r.getEstado().toUpperCase()));
            lista.append(String.format("   Cliente: %s | Paquete: %s\n",
                r.getCliente().getNombre(), r.getPaquete().getDestino()));
            lista.append(String.format("   Personas: %d | Total: $%,.0f\n\n",
                r.getCantidadPersonas(), r.getMontoTotal()));
        });

        lista.append("=================================================\n");
        lista.append(String.format("Total de reservas: %d\n", gestorReservas.getTotalReservas()));

        JOptionPane.showMessageDialog(null, lista.toString(), "Reservas",
            JOptionPane.INFORMATION_MESSAGE);
    }

    // ==================== MENÚ SERVICIOS ====================
    
    private void mostrarMenuServicios() {
        while (true) {
            String menu =
                "=================================================\n" +
                "          GESTIÓN DE SERVICIOS ADICIONALES          \n" +
                "=================================================\n\n" +
                "  1. Registrar Servicio\n" +
                "  2. Listar Servicios\n" +
                "  3. Modificar Servicio\n" +
                "  4. Eliminar Servicio\n" +
                "  5. Volver al Menú Principal\n\n" +
                String.format("Servicios registrados: %d\n\n", servicios.getTamanio()) +
                "Ingrese el número de opción:";

            String opcion = JOptionPane.showInputDialog(null, menu, "Menú Servicios",
                JOptionPane.PLAIN_MESSAGE);

            if (opcion == null || opcion.trim().equals("5")) break;

            try {
                switch (opcion.trim()) {
                    case "1": registrarServicio(); break;
                    case "2": listarServicios(); break;
                    case "3": modificarServicio(); break;
                    case "4": eliminarServicio(); break;
                    default: mostrarError("Opción Inválida", "Ingrese un número del 1 al 5");
                }
            } catch (Exception e) {
                mostrarError("Error", e.getMessage());
            }
        }
    }

    private void registrarServicio() {
        try {
            String codigo = JOptionPane.showInputDialog("Código del servicio:");
            if (codigo == null || codigo.trim().isEmpty()) return;

            ServicioAdicional temp = new ServicioAdicional(codigo);
            if (servicios.buscar(temp) != null) {
                mostrarError("Error", "Ya existe ese código");
                return;
            }

            String nombre = JOptionPane.showInputDialog("Nombre del servicio:");
            if (nombre == null || nombre.trim().isEmpty()) return;

            double precio = Double.parseDouble(JOptionPane.showInputDialog("Precio por persona:"));

            ServicioAdicional servicio = new ServicioAdicional(codigo, nombre, precio);
            servicios.agregar(servicio);
            
            mostrarExito("Éxito", "✓ Servicio registrado exitosamente\n\n" + servicio.toString());
        } catch (NumberFormatException e) {
            mostrarError("Error", "Precio inválido");
        }
    }

    private void listarServicios() {
        if (servicios.estaVacia()) {
            mostrarAdvertencia("Vacío", "No hay servicios registrados");
            return;
        }

        StringBuilder lista = new StringBuilder();
        lista.append("================================================= \n");
        lista.append("          SERVICIOS ADICIONALES DISPONIBLES          \n");
        lista.append("=================================================\n\n");

        final int[] cont = {1};
        servicios.paraCadaElemento(s -> {
            lista.append(String.format("%d. %s - %s\n", cont[0]++, s.getCodigo(), s.getNombre()));
            lista.append(String.format("   Precio: $%,.2f por persona\n\n", s.getPrecioPorPersona()));
        });

        lista.append("=================================================\n");
        lista.append(String.format("Total de servicios: %d\n", servicios.getTamanio()));

        JOptionPane.showMessageDialog(null, lista.toString(), "Servicios",
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void modificarServicio() {
        String codigo = JOptionPane.showInputDialog("Código del servicio:");
        if (codigo == null) return;

        ServicioAdicional temp = new ServicioAdicional(codigo);
        ServicioAdicional servicio = servicios.buscar(temp);

        if (servicio == null) {
            mostrarAdvertencia("No Encontrado", "Servicio no existe");
            return;
        }

        while (true) {
            String menu = String.format(
                "=================================================\n" +
                "          MODIFICAR SERVICIO                      \n" +
                "=================================================\n\n" +
                "Servicio: %s (%s)\n" +
                "Precio: $%,.2f\n\n" +
                "-------------------------------------------------------\n\n" +
                "  1. Modificar Nombre\n" +
                "  2. Modificar Precio\n" +
                "  3. Volver\n\n" +
                "Ingrese el número de opción:",
                servicio.getNombre(), servicio.getCodigo(),
                servicio.getPrecioPorPersona()
            );

            String opcion = JOptionPane.showInputDialog(menu);
            if (opcion == null || opcion.trim().equals("3")) break;

            try {
                switch (opcion.trim()) {
                    case "1":
                        String nombre = JOptionPane.showInputDialog("Nuevo Nombre:", servicio.getNombre());
                        if (nombre != null && !nombre.trim().isEmpty()) {
                            servicio.setNombre(nombre);
                            mostrarExito("Éxito", "✓ Nombre actualizado");
                        }
                        break;
                    case "2":
                        String precioStr = JOptionPane.showInputDialog("Nuevo Precio:", servicio.getPrecioPorPersona());
                        if (precioStr != null) {
                            servicio.setPrecioPorPersona(Double.parseDouble(precioStr.trim()));
                            mostrarExito("Éxito", "✓ Precio actualizado");
                        }
                        break;
                    default:
                        mostrarError("Opción Inválida", "Ingrese un número del 1 al 3");
                }
            } catch (NumberFormatException e) {
                mostrarError("Error", "Precio inválido");
            } catch (IllegalArgumentException e) {
                mostrarError("Error de validación", e.getMessage());
            }
        }
    }

    private void eliminarServicio() {
        String codigo = JOptionPane.showInputDialog("Código del servicio:");
        if (codigo == null) return;

        ServicioAdicional temp = new ServicioAdicional(codigo);
        if (servicios.eliminar(temp)) {
            mostrarExito("Éxito", "✓ Servicio eliminado");
        } else {
            mostrarAdvertencia("No Encontrado", "Servicio no existe");
        }
    }

    // ==================== COLA DE ATENCIÓN ====================
    
    private void gestionarColaAtencion() {
        while (true) {
            String menu = String.format(
                "=================================================\n" +
                "              COLA DE ATENCIÓN                         \n" +
                "=================================================\n\n" +
                "Personas en espera: %d\n\n" +
                "-------------------------------------------------------\n\n" +
                "  1. Agregar Cliente a Cola\n" +
                "  2. Atender Siguiente Cliente\n" +
                "  3. Ver Próximo Cliente\n" +
                "  4. Ver Tamaño de Cola\n" +
                "  5. Limpiar Cola\n" +
                "  6. Volver al Menú Principal\n\n" +
                "Ingrese el número de opción:",
                colaAtencion.getTamanio()
            );

            String opcion = JOptionPane.showInputDialog(menu);
            if (opcion == null || opcion.trim().equals("6")) break;

            switch (opcion.trim()) {
                case "1":
                    String nombre = JOptionPane.showInputDialog("Nombre del cliente:");
                    if (nombre != null && !nombre.trim().isEmpty()) {
                        colaAtencion.encolar(nombre);
                        mostrarExito("Éxito", 
                            String.format("✓ %s agregado a la cola\n\nPosición: %d", 
                            nombre, colaAtencion.getTamanio()));
                    }
                    break;
                    
                case "2":
                    if (!colaAtencion.estaVacia()) {
                        String cliente = colaAtencion.desencolar();
                        mostrarExito("Atendiendo", 
                            String.format("Cliente: %s\n\nQuedan %d personas en espera",
                            cliente, colaAtencion.getTamanio()));
                    } else {
                        mostrarAdvertencia("Cola Vacía", "No hay clientes en espera");
                    }
                    break;
                    
                case "3":
                    if (!colaAtencion.estaVacia()) {
                        mostrarExito("Próximo Cliente", 
                            "Siguiente en la fila:\n\n" + colaAtencion.verFrente());
                    } else {
                        mostrarAdvertencia("Cola Vacía", "No hay clientes");
                    }
                    break;
                    
                case "4":
                    mostrarExito("Tamaño de Cola", 
                        String.format("Personas en espera: %d", colaAtencion.getTamanio()));
                    break;
                    
                case "5":
                    int conf = JOptionPane.showConfirmDialog(null, 
                        "¿Limpiar toda la cola?\n\nEsta acción no se puede deshacer",
                        "Confirmar", JOptionPane.YES_NO_OPTION);
                    if (conf == JOptionPane.YES_OPTION) {
                        colaAtencion.limpiar();
                        mostrarExito("Éxito", "✓ Cola limpiada");
                    }
                    break;
                    
                default:
                    mostrarError("Opción Inválida", "Ingrese un número del 1 al 6");
            }
        }
    }

    // ==================== MENÚ REPORTES ====================
    
    private void mostrarMenuReportes() {
        while (true) {
            String menu =
                "=================================================\n" +
                "          REPORTES Y ESTADÍSTICAS                     \n" +
                "=================================================\n\n" +
                "  1. Reporte Completo\n" +
                "  2. Resumen Ejecutivo\n" +
                "  3. Estadísticas de Reservas\n" +
                "  4. Estadísticas de Pagos\n" +
                "  5. Estadísticas de Clientes\n" +
                "  6. Estadísticas de Paquetes\n" +
                "  7. Ocupación de Paquetes\n" +
                "  8. Últimos Pagos\n" +
                "  9. Volver al Menú Principal\n\n" +
                "Ingrese el número de opción:";

            String opcion = JOptionPane.showInputDialog(menu);
            if (opcion == null || opcion.trim().equals("9")) break;

            switch (opcion.trim()) {
                case "1":
                    mostrarReporteTexto(gestorEstadisticas.generarReporteCompleto(), 
                        "Reporte Completo");
                    break;
                case "2":
                    mostrarReporteTexto(gestorEstadisticas.generarReporteResumido(), 
                        "Resumen Ejecutivo");
                    break;
                case "3":
                    mostrarEstadisticasReservas();
                    break;
                case "4":
                    mostrarReporteTexto(gestorPagos.generarReportePagos(), 
                        "Estadísticas de Pagos");
                    break;
                case "5":
                    mostrarEstadisticasClientes();
                    break;
                case "6":
                    mostrarEstadisticasPaquetes();
                    break;
                case "7":
                    mostrarReporteTexto(
                        gestorEstadisticas.generarReporteOcupacionPaquetes(paquetes),
                        "Ocupación de Paquetes");
                    break;
                case "8":
                    mostrarUltimosPagos();
                    break;
                default:
                    mostrarError("Opción Inválida", "Ingrese un número del 1 al 9");
            }
        }
    }

    private void mostrarEstadisticasReservas() {
        int total = gestorReservas.getTotalReservas();
        int conf = gestorReservas.getTotalReservasConfirmadas();
        int pend = gestorReservas.getTotalReservasPendientes();
        int canc = gestorReservas.getTotalReservasCanceladas();

        String info = String.format(
            "=================================================\n" +
            "         ESTADÍSTICAS DE RESERVAS                      \n" +
            "=================================================\n\n" +
            "Total:        %d\n" +
            "Confirmadas:  %d (%.1f%%)\n" +
            "Pendientes:   %d (%.1f%%)\n" +
            "Canceladas:   %d (%.1f%%)\n\n" +
            "=================================================\n\n" +
            "Facturado:    $%,.2f\n" +
            "Descuentos:   $%,.2f\n",
            total, conf, total > 0 ? (double)conf * 100.0 / total : 0,
            pend, total > 0 ? (double)pend * 100.0 / total : 0,
            canc, total > 0 ? (double)canc * 100.0 / total : 0,
            gestorReservas.getMontoTotalFacturado(),
            gestorReservas.getMontoTotalDescuentos()
        );

        JOptionPane.showMessageDialog(null, info, "Estadísticas de Reservas",
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarEstadisticasClientes() {
        int masc = gestorReservas.getTotalClientesPorGenero("Masculino");
        int fem = gestorReservas.getTotalClientesPorGenero("Femenino");
        int otro = gestorReservas.getTotalClientesPorGenero("Otro");
        int total = masc + fem + otro;

        Cliente max = gestorReservas.getClienteQueMasGasto();
        Cliente min = gestorReservas.getClienteQueMenosGasto();

        StringBuilder info = new StringBuilder();
        info.append("=================================================\n");
        info.append("         ESTADÍSTICAS DE CLIENTES                      \n");
        info.append("=================================================\n\n");
        info.append(String.format("Total Atendidos: %d\n\n", total));
        info.append(String.format("Masculino:  %d (%.1f%%)\n", masc, total > 0 ? (double)masc * 100.0 / total : 0));
        info.append(String.format("Femenino:   %d (%.1f%%)\n", fem, total > 0 ? (double)fem * 100.0 / total : 0));
        info.append(String.format("Otro:       %d (%.1f%%)\n\n", otro, total > 0 ? (double)otro * 100.0 / total : 0));

        info.append("=================================================\n\n");

        if (max != null) {
            info.append("Cliente que MÁS gastó:\n");
            info.append(String.format("  • %s\n  • $%,.2f\n\n",
                max.getNombre(), gestorReservas.calcularGastoTotalCliente(max)));
        }

        if (min != null) {
            info.append("Cliente que MENOS gastó:\n");
            info.append(String.format("  • %s\n  • $%,.2f\n",
                min.getNombre(), gestorReservas.calcularGastoTotalCliente(min)));
        }

        JOptionPane.showMessageDialog(null, info.toString(), "Estadísticas de Clientes",
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarEstadisticasPaquetes() {
        int nac = gestorReservas.getTotalReservasPorTipoPaquete("nacional");
        int inter = gestorReservas.getTotalReservasPorTipoPaquete("internacional");
        int total = nac + inter;

        String info = String.format(
            "=================================================\n" +
            "         ESTADÍSTICAS DE PAQUETES                      \n" +
            "=================================================\n\n" +
            "Reservas por Tipo:\n\n" +
            "Nacional:       %d (%.1f%%)\n" +
            "Internacional:  %d (%.1f%%)\n\n" +
            "=================================================\n\n" +
            "Total Paquetes Registrados: %d\n",
            nac, total > 0 ? (double)nac * 100.0 / total : 0,
            inter, total > 0 ? (double)inter * 100.0 / total : 0,
            paquetes.getTamanio()
        );

        JOptionPane.showMessageDialog(null, info, "Estadísticas de Paquetes",
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarUltimosPagos() {
        String cantStr = JOptionPane.showInputDialog("¿Cuántos pagos desea ver?");
        if (cantStr == null) return;

        try {
            int cant = Integer.parseInt(cantStr);
            String[] pagos = gestorPagos.getUltimosPagos(cant);

            if (pagos.length == 0) {
                mostrarAdvertencia("Sin Datos", "No hay pagos registrados");
                return;
            }

            StringBuilder lista = new StringBuilder();
            lista.append("=================================================\n");
            lista.append("         ÚLTIMOS PAGOS REGISTRADOS                     \n");
            lista.append("=================================================\n\n");

            for (int i = 0; i < pagos.length && pagos[i] != null; i++) {
                lista.append(pagos[i]).append("\n\n");
            }

            JOptionPane.showMessageDialog(null, lista.toString(), "Historial de Pagos",
                JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            mostrarError("Error", "Cantidad inválida");
        }
    }

    private void mostrarReporteTexto(String reporte, String titulo) {
        JTextArea textArea = new JTextArea(reporte);
        textArea.setEditable(false);
        textArea.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 12));
        
        javax.swing.JScrollPane scrollPane = new javax.swing.JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(600, 500));
        
        JOptionPane.showMessageDialog(null, scrollPane, titulo, 
            JOptionPane.INFORMATION_MESSAGE);
    }

    // ==================== DATOS DE PRUEBA ====================
    
    private void cargarDatosPrueba() {
        try {
            // Clientes
            clientes.agregar(new Cliente("1001", "María González", 28, "Femenino",
                "3101234567", "maria@email.com", "Particular"));
            clientes.agregar(new Cliente("1002", "Carlos Rodríguez", 45, "Masculino",
                "3209876543", "carlos@email.com", "Empresa"));
            clientes.agregar(new Cliente("1003", "Ana Martínez", 33, "Femenino",
                "3156789012", "ana@email.com", "Particular"));
            clientes.agregar(new Cliente("1004", "Luis Pérez", 67, "Masculino",
                "3187654321", "luis@email.com", "Particular"));
            clientes.agregar(new Cliente("1005", "Laura Sánchez", 22, "Femenino",
                "3145678901", "laura@email.com", "Particular"));

            // Paquetes
            paquetes.agregar(new PaqueteTuristico("PAQ001", "Cartagena", 3,
                "Nacional", 350000, 20));
            paquetes.agregar(new PaqueteTuristico("PAQ002", "San Andrés", 5,
                "Nacional", 650000, 15));
            paquetes.agregar(new PaqueteTuristico("PAQ003", "Cancún", 7,
                "Internacional", 2500000, 25));
            paquetes.agregar(new PaqueteTuristico("PAQ004", "Europa", 15,
                "Internacional", 5500000, 10));
            paquetes.agregar(new PaqueteTuristico("PAQ005", "Eje Cafetero", 4,
                "Nacional", 450000, 18));

            // Crear algunas reservas de ejemplo
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH, 90);

            Cliente c1 = clientes.obtener(0);
            PaqueteTuristico p1 = paquetes.obtener(0);
            Reserva r1 = gestorReservas.crearReserva(c1, p1, 2, "efectivo", cal.getTime());
            gestorReservas.confirmarReserva(r1.getCodigo());
            gestorPagos.registrarPago(r1, "efectivo", r1.getMontoTotal());

            cal.add(Calendar.DAY_OF_MONTH, 30);
            Cliente c2 = clientes.obtener(1);
            PaqueteTuristico p2 = paquetes.obtener(2);
            Reserva r2 = gestorReservas.crearReserva(c2, p2, 12, "credito", cal.getTime());
            gestorReservas.confirmarReserva(r2.getCodigo());
            gestorPagos.registrarPago(r2, "credito", r2.getMontoTotal());

        } catch (Exception e) {
            System.err.println("Error al cargar datos de prueba: " + e.getMessage());
        }
    }

    // ==================== MÉTODOS AUXILIARES ====================
    
    private void inicializarServiciosBasicos() {
        servicios.agregar(new ServicioAdicional("SEG001", "Seguro de viaje", 80000));
        servicios.agregar(new ServicioAdicional("GUI001", "Guía privado", 120000));
        servicios.agregar(new ServicioAdicional("TRA001", "Transporte privado", 90000));
        servicios.agregar(new ServicioAdicional("ENT001", "Entradas a atracciones", 50000));
        servicios.agregar(new ServicioAdicional("COM001", "Comidas incluidas", 60000));
    }

    private void mostrarExito(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarError(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, titulo, JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarAdvertencia(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, titulo, JOptionPane.WARNING_MESSAGE);
    }

    private boolean confirmarSalida() {
        int respuesta = JOptionPane.showConfirmDialog(null,
            "=================================================\n" +
            "         CONFIRMAR SALIDA                         \n" +
            "=================================================\n\n" +
            "¿Está seguro que desea salir del sistema?\n\n" +
            "Todos los datos se conservarán hasta que\ncierre la aplicación.",
            "Confirmar Salida", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        return respuesta == JOptionPane.YES_OPTION;
    }

    public static void main(String[] args) {
        try {
            // Establecer el Look and Feel del sistema
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Mostrar splash screen (opcional)
        JOptionPane.showMessageDialog(null,
            "=================================================\n" +
            "         SISTEMA ECORUTAS                      \n" +
            "      Agencia de Viajes y Turismo               \n" +
            "=================================================\n" +
            "                  Versión 1.0                    \n" +
            "=================================================\n" +
            "             Bienvenido al sistema\n\n" +
            "    Datos de prueba cargados automáticamente",
            "ECORUTAS - Bienvenida", JOptionPane.INFORMATION_MESSAGE);
        
        SistemaEcorutas sistema = new SistemaEcorutas();
        sistema.mostrarMenuPrincipal();
        
        // Mensaje de despedida
        JOptionPane.showMessageDialog(null,
            "=================================================\n" +
            "         Gracias por usar SISTEMA ECORUTAS             \n" +
            "=================================================\n" +
            "              ¡Hasta pronto!                           \n" +
            "=================================================\n",
            "ECORUTAS - Despedida", JOptionPane.INFORMATION_MESSAGE);
        
        System.exit(0);
    }
}