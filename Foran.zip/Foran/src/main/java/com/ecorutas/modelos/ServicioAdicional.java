package com.ecorutas.modelos;

import com.ecorutas.estructuras.Cola;

public class ServicioAdicional {
    private String codigo;
    private String nombre;
    private double precioPorPersona;

    // Campos nuevos para manejar capacidad según los requisitos
    private int cupoMaximo; // -1 o 0 significa ilimitado
    private int cupoActual;
    private Cola<String> colaEspera; // Cola para clientes si se llena el cupo


    /**
     * Constructor ligero para búsquedas y operaciones.
     * Solo valida el código.
     */
    public ServicioAdicional(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío");
        }
        this.codigo = codigo;
        // Valores por defecto
        this.cupoMaximo = -1; 
        this.cupoActual = 0;
        this.colaEspera = new Cola<>();
    }

    /**
     * Constructor completo con manejo de cupos.
     * @param cupoMaximo El cupo máximo del servicio. -1 para ilimitado.
     */
    public ServicioAdicional(String codigo, String nombre, double precioPorPersona, int cupoMaximo) {
        validarDatos(codigo, nombre, precioPorPersona);
        this.codigo = codigo;
        this.nombre = nombre;
        this.precioPorPersona = precioPorPersona;
        this.cupoMaximo = cupoMaximo;
        this.cupoActual = 0;
        this.colaEspera = new Cola<>();
    }
    
    /**
     * Constructor anterior (sobrescrito) para compatibilidad.
     * Asume cupo ilimitado.
     */
    public ServicioAdicional(String codigo, String nombre, double precioPorPersona) {
        // Llama al constructor principal con cupo ilimitado (-1)
        this(codigo, nombre, precioPorPersona, -1);
    }


    private void validarDatos(String codigo, String nombre, double precio) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío");
        }
        if (precio < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
    }

    // --- EL MÉTODO QUE FALTABA ---
    /**
     * Intenta inscribir a un cliente y su grupo en el servicio.
     * Si hay cupo, lo inscribe y retorna true.
     * Si no hay cupo, lo agrega a la cola de espera y retorna false.
     *
     * @param clienteId El ID del cliente (documento)
     * @param cantidadPersonas El número de personas a inscribir
     * @return true si se inscribió, false si fue a cola de espera
     */
    public boolean inscribir(String clienteId, int cantidadPersonas) {
        // Si el cupo es ilimitado (0 o -1)
        if (cupoMaximo <= 0) {
            cupoActual += cantidadPersonas; // Seguimos contando por estadística
            return true; // Siempre hay espacio
        }

        // Si hay cupo disponible
        if (cupoActual + cantidadPersonas <= cupoMaximo) {
            cupoActual += cantidadPersonas;
            return true; // Inscripción exitosa
        } else {
            // No hay cupo, agregar a la cola de espera
            // Guardamos el cliente y cuántas personas son
            colaEspera.encolar(clienteId + ";" + cantidadPersonas);
            return false; // Se agregó a cola de espera
        }
    }


    // Getters y setters con validaciones
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío");
        }
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío");
        }
        this.nombre = nombre;
    }

    public double getPrecioPorPersona() {
        return precioPorPersona;
    }

    public void setPrecioPorPersona(double precioPorPersona) {
        if (precioPorPersona < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
        this.precioPorPersona = precioPorPersona;
    }
    
    // Getters para los nuevos campos
    public int getCupoMaximo() {
        return cupoMaximo;
    }

    public int getCupoActual() {
        return cupoActual;
    }

    public Cola<String> getColaEspera() {
        return colaEspera;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        ServicioAdicional servicio = (ServicioAdicional) obj;
        return codigo.equals(servicio.codigo);
    }

    @Override
    public int hashCode() {
        return codigo.hashCode();
    }

    @Override
    public String toString() {
        String cupoStr = (cupoMaximo <= 0) ? "Ilimitado" : (cupoActual + "/" + cupoMaximo);
        return String.format("ServicioAdicional{código='%s', nombre='%s', precio=$%,.2f, cupo=%s}",
            codigo, nombre, precioPorPersona, cupoStr);
    }
}