package com.ecorutas.modelos;

public class PaqueteTuristico {
    private String codigo;
    private String destino;
    private int duracionDias;
    private String tipo; // nacional/internacional
    private double precioPorPersona;
    private int plazasTotales;
    private int plazasDisponibles;
    private int totalReservasRealizadas;
    private double montoTotalVentas;

    /**
     * Constructor ligero para búsquedas y operaciones.
     * Solo valida el código.
     */
    public PaqueteTuristico(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío");
        }
        this.codigo = codigo;
    }

    public PaqueteTuristico(String codigo, String destino, int duracionDias, 
                           String tipo, double precioPorPersona, int plazasTotales) {
        validarDatos(codigo, destino, duracionDias, tipo, precioPorPersona, plazasTotales);
        this.codigo = codigo;
        this.destino = destino;
        this.duracionDias = duracionDias;
        this.tipo = tipo.toLowerCase();
        this.precioPorPersona = precioPorPersona;
        this.plazasTotales = plazasTotales;
        this.plazasDisponibles = plazasTotales;
        this.totalReservasRealizadas = 0;
        this.montoTotalVentas = 0;
    }

    private void validarDatos(String codigo, String destino, int duracionDias,
                             String tipo, double precioPorPersona, int plazasTotales) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío");
        }
        if (destino == null || destino.trim().isEmpty()) {
            throw new IllegalArgumentException("El destino no puede estar vacío");
        }
        if (duracionDias <= 0) {
            throw new IllegalArgumentException("La duración debe ser mayor a 0 días");
        }
        if (tipo == null || 
            (!tipo.equalsIgnoreCase("nacional") && !tipo.equalsIgnoreCase("internacional"))) {
            throw new IllegalArgumentException("El tipo debe ser 'Nacional' o 'Internacional'");
        }
        if (precioPorPersona < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
        if (plazasTotales <= 0) {
            throw new IllegalArgumentException("Las plazas totales deben ser mayores a 0");
        }
    }

    public boolean tieneDisponibilidad(int cantidadPersonas) {
        return plazasDisponibles >= cantidadPersonas && cantidadPersonas > 0;
    }

    public void reservarPlazas(int cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor a 0");
        }
        if (!tieneDisponibilidad(cantidad)) {
            throw new RuntimeException("No hay suficientes plazas disponibles. " +
                "Disponibles: " + plazasDisponibles + ", Solicitadas: " + cantidad);
        }
        plazasDisponibles -= cantidad;
        totalReservasRealizadas++;
    }

    public void liberarPlazas(int cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor a 0");
        }
        plazasDisponibles += cantidad;
        if (plazasDisponibles > plazasTotales) {
            plazasDisponibles = plazasTotales;
        }
    }

    public void registrarVenta(double monto) {
        montoTotalVentas += monto;
    }

    public double getPorcentajeOcupacion() {
        if (plazasTotales == 0) return 0;
        int plazasOcupadas = plazasTotales - plazasDisponibles;
        return (double) plazasOcupadas / plazasTotales * 100.0;
    }

    public int getPlazasOcupadas() {
        return plazasTotales - plazasDisponibles;
    }

    public double getPromedioPlazasVendidas() {
        if (totalReservasRealizadas == 0) {
            return 0;
        }
        return (double) getPlazasOcupadas() / totalReservasRealizadas;
    }

    // Getters y Setters
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío");
        }
        this.codigo = codigo;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        if (destino == null || destino.trim().isEmpty()) {
            throw new IllegalArgumentException("El destino no puede estar vacío");
        }
        this.destino = destino;
    }

    public int getDuracionDias() {
        return duracionDias;
    }

    public void setDuracionDias(int duracionDias) {
        if (duracionDias <= 0) {
            throw new IllegalArgumentException("La duración debe ser mayor a 0 días");
        }
        this.duracionDias = duracionDias;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        if (tipo == null || 
            (!tipo.equalsIgnoreCase("nacional") && !tipo.equalsIgnoreCase("internacional"))) {
            throw new IllegalArgumentException("El tipo debe ser 'Nacional' o 'Internacional'");
        }
        this.tipo = tipo.toLowerCase();
    }

    public double getPrecioPorPersona() {
        return precioPorPersona;
    }

    public void setPrecioPorPersona(double precioPorPersona) {
        if (precioPorPersona < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
        this.precioPorPersona = precioPorPersona;
    }

    public int getPlazasTotales() {
        return plazasTotales;
    }

    public void setPlazasTotales(int nuevasPlazasTotales) {
        if (nuevasPlazasTotales <= 0) {
            throw new IllegalArgumentException("Las plazas totales deben ser mayores a 0");
        }
        int plazasOcupadas = getPlazasOcupadas();
        if (nuevasPlazasTotales < plazasOcupadas) {
            throw new IllegalArgumentException("Las plazas totales no pueden ser menores que las plazas ya ocupadas (" + plazasOcupadas + ")");
        }
        // Ajustar plazas disponibles
        this.plazasDisponibles = nuevasPlazasTotales - plazasOcupadas;
        this.plazasTotales = nuevasPlazasTotales;
    }

    public int getPlazasDisponibles() {
        return plazasDisponibles;
    }

    public void setPlazasDisponibles(int plazasDisponibles) {
        if (plazasDisponibles < 0) {
            throw new IllegalArgumentException("Las plazas disponibles no pueden ser negativas");
        }
        this.plazasDisponibles = plazasDisponibles;
    }

    public int getTotalReservasRealizadas() {
        return totalReservasRealizadas;
    }

    public double getMontoTotalVentas() {
        return montoTotalVentas;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        PaqueteTuristico paquete = (PaqueteTuristico) obj;
        return codigo.equals(paquete.codigo);
    }

    @Override
    public int hashCode() {
        return codigo.hashCode();
    }

    @Override
    public String toString() {
        return String.format(
            "PaqueteTuristico{código='%s', destino='%s', duración=%d días, " +
            "tipo='%s', precio=%.2f, plazasTotales=%d, disponibles=%d, " +
            "ocupación=%.1f%%, ventas=%.2f}",
            codigo, destino, duracionDias, tipo, precioPorPersona, 
            plazasTotales, plazasDisponibles, getPorcentajeOcupacion(), montoTotalVentas
        );
    }
}