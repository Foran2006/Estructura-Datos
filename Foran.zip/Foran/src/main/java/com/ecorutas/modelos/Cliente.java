package com.ecorutas.modelos;

public class Cliente {
    private String documento;
    private String nombre;
    private int edad;
    private String genero;
    private String telefono;
    private String correo;
    private String tipoCliente;
    // particular/empresa
    private int reservasRealizadas; // Para control de cliente frecuente

    /**
     * Constructor ligero para búsquedas y operaciones.
     * Solo valida el documento.
     */
    public Cliente(String documento) {
        if (documento == null || documento.trim().isEmpty()) {
            throw new IllegalArgumentException("El documento no puede estar vacío");
        }
        this.documento = documento;
    }

    public Cliente(String documento, String nombre, int edad, String genero, 
                  String telefono, String correo, String tipoCliente) {
        validarDatos(documento, nombre, edad, genero, telefono, correo, tipoCliente);
        this.documento = documento;
        this.nombre = nombre;
        this.edad = edad;
        this.genero = genero;
        this.telefono = telefono;
        this.correo = correo;
        this.tipoCliente = tipoCliente.toLowerCase();
        this.reservasRealizadas = 0;
    }

    private void validarDatos(String documento, String nombre, int edad, String genero,
                             String telefono, String correo, String tipoCliente) {
        if (documento == null || documento.trim().isEmpty()) {
            throw new IllegalArgumentException("El documento no puede estar vacío");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío");
        }
        if (edad < 0 || edad > 150) {
            throw new IllegalArgumentException("La edad debe estar entre 0 y 150 años");
        }
        if (genero == null || genero.trim().isEmpty()) {
            throw new IllegalArgumentException("El género no puede estar vacío");
        }
        if (telefono == null || telefono.trim().isEmpty()) {
            throw new IllegalArgumentException("El teléfono no puede estar vacío");
        }
        if (correo == null || correo.trim().isEmpty()) {
            throw new IllegalArgumentException("El correo no puede estar vacío");
        }
        if (!correo.contains("@")) {
            throw new IllegalArgumentException("El correo debe tener un formato válido");
        }
        if (tipoCliente == null || 
            (!tipoCliente.equalsIgnoreCase("particular") && !tipoCliente.equalsIgnoreCase("empresa"))) {
            throw new IllegalArgumentException("El tipo de cliente debe ser 'Particular' o 'Empresa'");
        }
    }

    // Getters y setters con validaciones
    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        if (documento == null || documento.trim().isEmpty()) {
            throw new IllegalArgumentException("El documento no puede estar vacío");
        }
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío");
        }
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        if (edad < 0 || edad > 150) {
            throw new IllegalArgumentException("La edad debe estar entre 0 y 150 años");
        }
        this.edad = edad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        if (genero == null || genero.trim().isEmpty()) {
            throw new IllegalArgumentException("El género no puede estar vacío");
        }
        this.genero = genero;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        if (telefono == null || telefono.trim().isEmpty()) {
            throw new IllegalArgumentException("El teléfono no puede estar vacío");
        }
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        if (correo == null || correo.trim().isEmpty() || !correo.contains("@")) {
            throw new IllegalArgumentException("El correo debe tener un formato válido");
        }
        this.correo = correo;
    }

    public String getTipoCliente() {
        return tipoCliente;
    }

    public void setTipoCliente(String tipoCliente) {
        if (tipoCliente == null || 
            (!tipoCliente.equalsIgnoreCase("particular") && !tipoCliente.equalsIgnoreCase("empresa"))) {
            throw new IllegalArgumentException("El tipo de cliente debe ser 'Particular' o 'Empresa'");
        }
        this.tipoCliente = tipoCliente.toLowerCase();
    }

    public int getReservasRealizadas() {
        return reservasRealizadas;
    }

    public void incrementarReservas() {
        this.reservasRealizadas++;
    }

    public void setReservasRealizadas(int reservasRealizadas) {
        if (reservasRealizadas < 0) {
            throw new IllegalArgumentException("El número de reservas no puede ser negativo");
        }
        this.reservasRealizadas = reservasRealizadas;
    }

    public boolean esClienteFrecuente() {
        return reservasRealizadas > 2;
    }

    public String getRangoEdad() {
        if (edad < 18) return "Menor de 18";
        if (edad <= 40) return "18-40";
        if (edad <= 65) return "41-65";
        return "Mayor de 65";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Cliente cliente = (Cliente) obj;
        return documento.equals(cliente.documento);
    }

    @Override
    public int hashCode() {
        return documento.hashCode();
    }

    @Override
    public String toString() {
        return String.format(
            "Cliente{documento='%s', nombre='%s', edad=%d, género='%s', " +
            "teléfono='%s', correo='%s', tipo='%s', reservas=%d}",
            documento, nombre, edad, genero, telefono, correo, tipoCliente, reservasRealizadas
        );
    }
}