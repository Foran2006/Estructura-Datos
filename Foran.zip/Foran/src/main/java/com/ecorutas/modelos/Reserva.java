package com.ecorutas.modelos;

import com.ecorutas.estructuras.ListaEnlazada;
import java.util.Date;
public class Reserva {
    private String codigo;
    private Cliente cliente;
    private PaqueteTuristico paquete;
    private int cantidadPersonas;
    private ListaEnlazada<ServicioAdicional> serviciosAdicionales; // CORREGIDO
    private String estado;
    // confirmada, pendiente, cancelada
    private double montoBase;
    private double montoServicios;
    private double montoDescuentos;
    private double montoRecargos;
    private double montoTotal;
    private Date fechaReserva;
    private Date fechaViaje;
    private String medioPago;
    private int numeroReservasClienteAnio;
    // Para descuento cliente frecuente

    public Reserva(String codigo, Cliente cliente, PaqueteTuristico paquete, 
                  int cantidadPersonas, String medioPago) {
        validarDatos(codigo, cliente, paquete, cantidadPersonas, medioPago);
        this.codigo = codigo;
        this.cliente = cliente;
        this.paquete = paquete;
        this.cantidadPersonas = cantidadPersonas;
        this.serviciosAdicionales = new ListaEnlazada<>();
        // CORREGIDO
        this.estado = "pendiente";
        this.medioPago = medioPago.toLowerCase();
        this.fechaReserva = new Date();
        this.numeroReservasClienteAnio = 0;
        this.montoDescuentos = 0;
        this.montoRecargos = 0;
        
        calcularMontoTotal();
    }

    private void validarDatos(String codigo, Cliente cliente, PaqueteTuristico paquete,
                             int cantidadPersonas, String medioPago) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de reserva no puede estar vacío");
        }
        if (cliente == null) {
            throw new IllegalArgumentException("El cliente no puede ser nulo");
        }
        if (paquete == null) {
            throw new IllegalArgumentException("El paquete no puede ser nulo");
        }
        if (cantidadPersonas <= 0) {
            throw new IllegalArgumentException("La cantidad de personas debe ser mayor a 0");
        }
        if (medioPago == null || medioPago.trim().isEmpty()) {
            throw new IllegalArgumentException("El medio de pago no puede estar vacío");
        }
    }

    public void agregarServicioAdicional(ServicioAdicional servicio) {
        if (servicio == null) {
            throw new IllegalArgumentException("El servicio no puede ser nulo");
        }
        serviciosAdicionales.agregar(servicio);
        calcularMontoTotal();
    }

    public void calcularMontoTotal() {
        // 1. Costo base del paquete
        montoBase = paquete.getPrecioPorPersona() * cantidadPersonas;
        // 2. Sumar servicios adicionales
        montoServicios = 0;
        serviciosAdicionales.paraCadaElemento(servicio -> {
            montoServicios += servicio.getPrecioPorPersona() * cantidadPersonas;
        });
        // 3. Calcular monto sin descuentos ni recargos
        double montoSinAjustes = montoBase + montoServicios;
        // 4. Aplicar descuentos
        calcularDescuentos(montoSinAjustes);
        // 5. Aplicar recargos
        calcularRecargos(montoSinAjustes - montoDescuentos);
        // 6. Calcular monto total final
        montoTotal = montoSinAjustes - montoDescuentos + montoRecargos;
        // Asegurar que el monto no sea negativo
        if (montoTotal < 0) {
            montoTotal = 0;
        }
    }

    private void calcularDescuentos(double montoBase) {
        montoDescuentos = 0;
        // Descuento por cliente frecuente (más de 2 reservas en el año): 12%
        if (numeroReservasClienteAnio > 2) {
            montoDescuentos += montoBase * 0.12;
        }

        // Descuento por contratación anticipada (más de 60 días): 8%
        if (esContratacionAnticipada()) {
            montoDescuentos += montoBase * 0.08;
        }

        // Descuento por grupo grande (más de 10 personas): 10%
        if (cantidadPersonas > 10) {
            montoDescuentos += montoBase * 0.10;
        }
    }

    private void calcularRecargos(double montoConDescuento) {
        montoRecargos = 0;
        // Recargo por pago con tarjeta de crédito: 3%
        if (medioPago.equalsIgnoreCase("credito")) {
            montoRecargos = montoConDescuento * 0.03;
        }
    }

    private boolean esContratacionAnticipada() {
        if (fechaViaje == null) {
            return false;
        }
        long diferenciaDias = (fechaViaje.getTime() - fechaReserva.getTime()) / (1000 * 60 * 60 * 24);
        return diferenciaDias > 60;
    }

    public void aplicarDescuentoManual(double montoDescuento) {
        if (montoDescuento < 0) {
            throw new IllegalArgumentException("El descuento no puede ser negativo");
        }
        this.montoDescuentos += montoDescuento;
        calcularMontoTotal();
    }

    public void aplicarPenalidad(double montoPenalidad) {
        if (montoPenalidad < 0) {
            throw new IllegalArgumentException("La penalidad no puede ser negativa");
        }
        this.montoRecargos += montoPenalidad;
        calcularMontoTotal();
    }

    public double calcularPenalidadCancelacion() {
        if (fechaViaje == null) {
            return 0;
        }
        
        long diferenciaDias = (fechaViaje.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24);
        // Si cancela con menos de 15 días de anticipación: penalidad del 20%
        if (diferenciaDias < 15) {
            return montoTotal * 0.20;
        }
        
        return 0;
    }

    // Getters y Setters
    public String getCodigo() {
        return codigo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public PaqueteTuristico getPaquete() {
        return paquete;
    }

    public int getCantidadPersonas() {
        return cantidadPersonas;
    }

    public void setCantidadPersonas(int cantidadPersonas) {
        if (cantidadPersonas <= 0) {
            throw new IllegalArgumentException("La cantidad de personas debe ser mayor a 0");
        }
        this.cantidadPersonas = cantidadPersonas;
        calcularMontoTotal();
    }

    public ListaEnlazada<ServicioAdicional> getServiciosAdicionales() {
        return serviciosAdicionales;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        if (estado == null || estado.trim().isEmpty()) {
            throw new IllegalArgumentException("El estado no puede estar vacío");
        }
        this.estado = estado.toLowerCase();
    }

    public double getMontoTotal() {
        return montoTotal;
    }

    public double getMontoBase() {
        return montoBase;
    }

    public double getMontoServicios() {
        return montoServicios;
    }

    public double getMontoDescuentos() {
        return montoDescuentos;
    }

    public double getMontoRecargos() {
        return montoRecargos;
    }

    public Date getFechaReserva() {
        return fechaReserva;
    }

    public Date getFechaViaje() {
        return fechaViaje;
    }

    public void setFechaViaje(Date fechaViaje) {
        this.fechaViaje = fechaViaje;
        calcularMontoTotal();
        // Recalcular por descuento anticipado
    }

    public String getMedioPago() {
        return medioPago;
    }

    public void setMedioPago(String medioPago) {
        if (medioPago == null || medioPago.trim().isEmpty()) {
            throw new IllegalArgumentException("El medio de pago no puede estar vacío");
        }
        this.medioPago = medioPago.toLowerCase();
        calcularMontoTotal();
        // Recalcular por posible recargo
    }

    public int getNumeroReservasClienteAnio() {
        return numeroReservasClienteAnio;
    }

    public void setNumeroReservasClienteAnio(int numeroReservasClienteAnio) {
        this.numeroReservasClienteAnio = numeroReservasClienteAnio;
        calcularMontoTotal();
        // Recalcular por descuento cliente frecuente
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Reserva reserva = (Reserva) obj;
        return codigo.equals(reserva.codigo);
    }

    @Override
    public int hashCode() {
        return codigo.hashCode();
    }

    @Override
    public String toString() {
        return String.format(
            "Reserva{codigo='%s', cliente='%s', paquete='%s', personas=%d, " +
            "estado='%s', montoBase=%.2f, servicios=%.2f, descuentos=%.2f, " +
            "recargos=%.2f, total=%.2f, medioPago='%s'}",
            codigo, cliente.getNombre(), paquete.getDestino(), cantidadPersonas,
            estado, montoBase, montoServicios, montoDescuentos, 
            montoRecargos, montoTotal, medioPago
        );
    }
}