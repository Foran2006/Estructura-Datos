package com.ecorutas.estructuras;

/**
 * @param <T> Tipo de dato a almacenar
 */
public class ListaEnlazada<T> {
    private Nodo primero;
    private int tamanio;

    private class Nodo {
        T dato;
        Nodo siguiente;

        Nodo(T dato) {
            this.dato = dato;
            this.siguiente = null;
        }
    }

    public ListaEnlazada() {
        this.primero = null;
        this.tamanio = 0;
    }

    public void agregar(T dato) {
        if (dato == null) {
            throw new IllegalArgumentException("No se puede agregar un elemento nulo");
        }
        
        Nodo nuevoNodo = new Nodo(dato);
        if (primero == null) {
            primero = nuevoNodo;
        } else {
            Nodo actual = primero;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevoNodo;
        }
        tamanio++;
    }

    public boolean eliminar(T dato) {
        if (primero == null || dato == null) {
            return false;
        }

        if (primero.dato.equals(dato)) {
            primero = primero.siguiente;
            tamanio--;
            return true;
        }

        Nodo actual = primero;
        while (actual.siguiente != null && !actual.siguiente.dato.equals(dato)) {
            actual = actual.siguiente;
        }

        if (actual.siguiente != null) {
            actual.siguiente = actual.siguiente.siguiente;
            tamanio--;
            return true;
        }

        return false;
    }

    public T buscar(T dato) {
        if (dato == null) {
            return null;
        }
        
        Nodo actual = primero;
        while (actual != null) {
            if (actual.dato.equals(dato)) {
                return actual.dato;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    /**
     * Obtiene un elemento por índice
     */
    public T obtener(int indice) {
        if (indice < 0 || indice >= tamanio) {
            throw new IndexOutOfBoundsException("Índice fuera de rango: " + indice);
        }
        
        Nodo actual = primero;
        for (int i = 0; i < indice; i++) {
            actual = actual.siguiente;
        }
        return actual.dato;
    }

    /**
     * Método para iterar sobre todos los elementos
     * Permite aplicar una operación a cada elemento
     */
    public void paraCadaElemento(Consumidor<T> accion) {
        Nodo actual = primero;
        while (actual != null) {
            accion.aceptar(actual.dato);
            actual = actual.siguiente;
        }
    }

    /**
     * Convierte la lista a un arreglo
     */
    @SuppressWarnings("unchecked")
    public T[] aArreglo() {
        if (tamanio == 0) {
            return (T[]) new Object[0];
        }
        
        T[] arreglo = (T[]) new Object[tamanio];
        Nodo actual = primero;
        int i = 0;
        while (actual != null) {
            arreglo[i++] = actual.dato;
            actual = actual.siguiente;
        }
        return arreglo;
    }

    /**
     * Filtra elementos según una condición
     */
    public ListaEnlazada<T> filtrar(Predicado<T> condicion) {
        ListaEnlazada<T> resultado = new ListaEnlazada<>();
        Nodo actual = primero;
        while (actual != null) {
            if (condicion.evaluar(actual.dato)) {
                resultado.agregar(actual.dato);
            }
            actual = actual.siguiente;
        }
        return resultado;
    }

    /**
     * Cuenta elementos que cumplen una condición
     */
    public int contar(Predicado<T> condicion) {
        int contador = 0;
        Nodo actual = primero;
        while (actual != null) {
            if (condicion.evaluar(actual.dato)) {
                contador++;
            }
            actual = actual.siguiente;
        }
        return contador;
    }

    /**
     * Busca el primer elemento que cumple una condición
     */
    public T buscarPor(Predicado<T> condicion) {
        Nodo actual = primero;
        while (actual != null) {
            if (condicion.evaluar(actual.dato)) {
                return actual.dato;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public boolean estaVacia() {
        return primero == null;
    }

    public int getTamanio() {
        return tamanio;
    }

    public void limpiar() {
        primero = null;
        tamanio = 0;
    }

    /**
     * Verifica si contiene un elemento
     */
    public boolean contiene(T dato) {
        return buscar(dato) != null;
    }

    @Override
    public String toString() {
        if (estaVacia()) {
            return "[]";
        }
        
        StringBuilder sb = new StringBuilder("[");
        Nodo actual = primero;
        while (actual != null) {
            sb.append(actual.dato);
            if (actual.siguiente != null) {
                sb.append(", ");
            }
            actual = actual.siguiente;
        }
        sb.append("]");
        return sb.toString();
    }

    // Interfaces funcionales para operaciones
    public interface Consumidor<T> {
        void aceptar(T elemento);
    }

    public interface Predicado<T> {
        boolean evaluar(T elemento);
    }
}