package com.ecorutas.servicios;

import com.ecorutas.modelos.*;
import com.ecorutas.estructuras.Pila;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GestorPagos {
    private double[] montoPorMedioPago = new double[4]; // 0: efectivo, 1: debito, 2: credito, 3: transferencia
    private int[] cantidadPorMedioPago = new int[4];
    private Pila<String> historialPagos = new Pila<>(); // Pila para secuencia de pagos

    public void registrarPago(Reserva reserva, String medioPago, double monto) {
        if (reserva == null) {
            throw new IllegalArgumentException("La reserva no puede ser nula");
        }
        if (monto < 0) {
            throw new IllegalArgumentException("El monto no puede ser negativo");
        }
        if (!reserva.getEstado().equals("confirmada")) {
            throw new RuntimeException("La reserva debe estar confirmada para registrar pago");
        }

        int indice = obtenerIndiceMedioPago(medioPago);
        montoPorMedioPago[indice] += monto;
        cantidadPorMedioPago[indice]++;
        
        // Registrar en pila para historial
        String registro = String.format("Pago: %s - Reserva: %s - Monto: $%,.2f - Fecha: %s",
            medioPago, reserva.getCodigo(), monto, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        historialPagos.push(registro);
    }

    private int obtenerIndiceMedioPago(String medio) {
        switch (medio.toLowerCase()) {
            case "efectivo": return 0;
            case "debito": return 1;
            case "credito": return 2;
            case "transferencia": return 3;
            default: throw new IllegalArgumentException("Medio de pago inválido: " + medio);
        }
    }

    private String obtenerNombreMedioPago(int indice) {
        switch (indice) {
            case 0: return "Efectivo";
            case 1: return "Débito";
            case 2: return "Crédito";
            case 3: return "Transferencia";
            default: throw new IllegalArgumentException("Índice inválido");
        }
    }

    public double getMontoTotalRecaudado() {
        double total = 0;
        for (double monto : montoPorMedioPago) {
            total += monto;
        }
        return total;
    }

    public double getMontoTotalPorMedioPago(String medio) {
        return montoPorMedioPago[obtenerIndiceMedioPago(medio)];
    }

    public int getCantidadPorMedioPago(String medio) {
        return cantidadPorMedioPago[obtenerIndiceMedioPago(medio)];
    }

    public double getPorcentajePorMedioPago(String medio) {
        double total = getMontoTotalRecaudado();
        if (total == 0) return 0;
        return (getMontoTotalPorMedioPago(medio) / total) * 100;
    }

    public int getTotalPagosRealizados() {
        int total = 0;
        for (int cant : cantidadPorMedioPago) {
            total += cant;
        }
        return total;
    }

    public String[] getUltimosPagos(int cantidad) {
        if (cantidad <= 0) {
            return new String[0];
        }
        
        cantidad = Math.min(cantidad, historialPagos.getTamanio());
        String[] pagos = new String[cantidad];
        Pila<String> pilaTemp = new Pila<>();
        
        int i = 0;
        while (i < cantidad && !historialPagos.estaVacia()) {
            String pago = historialPagos.pop();
            pagos[i++] = pago;
            pilaTemp.push(pago);
        }
        
        // Restaurar la pila original
        while (!pilaTemp.estaVacia()) {
            historialPagos.push(pilaTemp.pop());
        }
        
        return pagos;
    }

    /**
     * Genera reporte detallado de pagos
     */
    public String generarReportePagos() {
        StringBuilder reporte = new StringBuilder();
        double totalRecaudado = getMontoTotalRecaudado();
        
        reporte.append("═══════════════════════════════════════════════\n");
        reporte.append("        REPORTE DETALLADO DE PAGOS\n");
        reporte.append("═══════════════════════════════════════════════\n\n");
        
        reporte.append(String.format("Total Recaudado: $%,.2f\n", totalRecaudado));
        reporte.append(String.format("Total de Pagos: %d\n\n", getTotalPagosRealizados()));
        
        reporte.append("Distribución por Medio de Pago:\n");
        reporte.append("───────────────────────────────────────────────\n");
        
        for (int i = 0; i < 4; i++) {
            String medio = obtenerNombreMedioPago(i);
            double monto = montoPorMedioPago[i];
            int cantidadPagos = cantidadPorMedioPago[i];
            double porcentaje = totalRecaudado > 0 ? (monto / totalRecaudado) * 100 : 0;
            
            reporte.append(String.format("%-15s: $%,12.2f (%5.1f%%) - %d pagos\n",
                medio, monto, porcentaje, cantidadPagos));
        }
        
        reporte.append("═══════════════════════════════════════════════\n");
        
        return reporte.toString();
    }

    /**
     * Obtiene el medio de pago más utilizado
     */
    public String getMedioPagoMasUtilizado() {
        int indiceMax = 0;
        double montoMax = montoPorMedioPago[0];
        
        for (int i = 1; i < montoPorMedioPago.length; i++) {
            if (montoPorMedioPago[i] > montoMax) {
                montoMax = montoPorMedioPago[i];
                indiceMax = i;
            }
        }
        
        return obtenerNombreMedioPago(indiceMax);
    }

    /**
     * Limpia todos los registros de pagos
     */
    public void limpiar() {
        for (int i = 0; i < montoPorMedioPago.length; i++) {
            montoPorMedioPago[i] = 0;
            cantidadPorMedioPago[i] = 0;
        }
        historialPagos.limpiar();
    }

    // Getters para acceso directo a los arrays
    public double[] getMontoPorMedioPago() {
        return montoPorMedioPago.clone();
    }

    public int[] getCantidadPorMedioPago() {
        return cantidadPorMedioPago.clone();
    }

    public Pila<String> getHistorialPagos() {
        return historialPagos;
    }
}