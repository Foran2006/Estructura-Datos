package com.ecorutas.servicios;

import com.ecorutas.modelos.*;
import com.ecorutas.estructuras.ListaEnlazada;

public class GestorEstadisticas {
    private GestorReservas gestorReservas;
    private GestorPagos gestorPagos;

    public GestorEstadisticas(GestorReservas gestorReservas, GestorPagos gestorPagos) {
        this.gestorReservas = gestorReservas;
        this.gestorPagos = gestorPagos;
    }

    /**
     * Genera el reporte estadístico completo con todos los datos solicitados
     */
    public String generarReporteCompleto() {
        StringBuilder reporte = new StringBuilder();
        
        reporte.append("============================================================\n");
        reporte.append("║        SISTEMA ECORUTAS - REPORTE ESTADÍSTICO COMPLETO   ║\n");
        reporte.append("============================================================\n\n");
        
        reporte.append(generarSeccionReservas());
        reporte.append("\n");
        reporte.append(generarSeccionPagos());
        reporte.append("\n");
        reporte.append(generarSeccionClientes());
        reporte.append("\n");
        reporte.append(generarSeccionPaquetes());
        reporte.append("\n");
        reporte.append(generarSeccionServicios());
        reporte.append("\n");
        reporte.append(generarSeccionEdades());
        
        return reporte.toString();
    }

    /**
     * Sección 1: Estadísticas de Reservas
     */
    private String generarSeccionReservas() {
        StringBuilder sb = new StringBuilder();
        
        int totalReservas = gestorReservas.getTotalReservas();
        int confirmadas = gestorReservas.getTotalReservasConfirmadas();
        int pendientes = gestorReservas.getTotalReservasPendientes();
        int canceladas = gestorReservas.getTotalReservasCanceladas();
        int enEspera = gestorReservas.getTotalReservasEnEspera();
        
        sb.append("====================================\n");
        sb.append("│  1. ESTADÍSTICAS DE RESERVAS     │\n");
        sb.append("====================================\n");

        sb.append(String.format("  • Total de Reservas Realizadas:  %d\n", totalReservas));
        sb.append(String.format("  • Reservas Confirmadas:          %d\n", confirmadas));
        sb.append(String.format("  • Reservas Pendientes:           %d\n", pendientes));
        sb.append(String.format("  • Reservas Canceladas:           %d\n", canceladas));
        sb.append(String.format("  • Reservas en Lista de Espera:   %d\n\n", enEspera));
        
        if (totalReservas > 0) {
            double porcConfirmadas = (confirmadas * 100.0) / totalReservas;
            double porcPendientes = (pendientes * 100.0) / totalReservas;
            double porcCanceladas = (canceladas * 100.0) / totalReservas;
            
            sb.append("  Distribución Porcentual:\n");
            sb.append(String.format("    ├─ Confirmadas:  %5.1f%%\n", porcConfirmadas));
            sb.append(String.format("    ├─ Pendientes:   %5.1f%%\n", porcPendientes));
            sb.append(String.format("    └─ Canceladas:   %5.1f%%\n", porcCanceladas));
        }
        
        return sb.toString();
    }

    /**
     * Sección 2: Estadísticas de Pagos
     */
    private String generarSeccionPagos() {
        StringBuilder sb = new StringBuilder();
        
        double montoTotal = gestorPagos.getMontoTotalRecaudado();
        double montoDescuentos = gestorReservas.getMontoTotalDescuentos();

        sb.append("===============================================\n");
        sb.append("│  2. ESTADÍSTICAS DE PAGOS Y FACTURACIÓN     │\n");
        sb.append("===============================================\n");

        sb.append(String.format("  • Monto Total Facturado:        $%,15.2f\n", montoTotal));
        sb.append(String.format("  • Total de Descuentos Aplicados: $%,15.2f\n\n", montoDescuentos));
        
        sb.append("  Recaudación por Medio de Pago:\n");
        String[] medios = {"efectivo", "debito", "credito", "transferencia"};
        String[] nombres = {"Efectivo", "Débito", "Crédito", "Transferencia"};
        
        for (int i = 0; i < medios.length; i++) {
            double monto = gestorPagos.getMontoTotalPorMedioPago(medios[i]);
            double porcentaje = gestorPagos.getPorcentajePorMedioPago(medios[i]);
            int cantidad = gestorPagos.getCantidadPorMedioPago(medios[i]);
            
            sb.append(String.format("    ├─ %-14s: $%,12.2f (%5.1f%%) - %d pagos\n",
                nombres[i], monto, porcentaje, cantidad));
        }
        
        sb.append(String.format("\n  • Medio de Pago Más Utilizado:  %s\n", 
            gestorPagos.getMedioPagoMasUtilizado()));
        
        return sb.toString();
    }

    /**
     * Sección 3: Estadísticas de Clientes
     */
    private String generarSeccionClientes() {
        StringBuilder sb = new StringBuilder();
        
        int totalMasculino = gestorReservas.getTotalClientesPorGenero("Masculino");
        int totalFemenino = gestorReservas.getTotalClientesPorGenero("Femenino");
        int totalOtro = gestorReservas.getTotalClientesPorGenero("Otro");
        int totalClientes = totalMasculino + totalFemenino + totalOtro;
        
        Cliente clienteMax = gestorReservas.getClienteQueMasGasto();
        Cliente clienteMin = gestorReservas.getClienteQueMenosGasto();
        
        sb.append("====================================\n");
        sb.append("│  3. ESTADÍSTICAS DE CLIENTES     │\n");
        sb.append("====================================\n");
        
        sb.append(String.format("  • Total de Clientes Atendidos:  %d\n\n", totalClientes));
        
        sb.append("  Clientes por Género:\n");
        if (totalClientes > 0) {
            sb.append(String.format("    ├─ Masculino:  %3d (%5.1f%%)\n", 
                totalMasculino, (totalMasculino * 100.0) / totalClientes));
            sb.append(String.format("    ├─ Femenino:   %3d (%5.1f%%)\n", 
                totalFemenino, (totalFemenino * 100.0) / totalClientes));
            sb.append(String.format("    └─ Otro:       %3d (%5.1f%%)\n\n", 
                totalOtro, (totalOtro * 100.0) / totalClientes));
        }
        
        if (clienteMax != null) {
            double gastoMax = gestorReservas.calcularGastoTotalCliente(clienteMax);
            sb.append("  Cliente que Más Gastó:\n");
            sb.append(String.format("    • Nombre:     %s\n", clienteMax.getNombre()));
            sb.append(String.format("    • Documento:  %s\n", clienteMax.getDocumento()));
            sb.append(String.format("    • Monto:      $%,.2f\n\n", gastoMax));
        }
        
        if (clienteMin != null) {
            double gastoMin = gestorReservas.calcularGastoTotalCliente(clienteMin);
            sb.append("  Cliente que Menos Gastó:\n");
            sb.append(String.format("    • Nombre:     %s\n", clienteMin.getNombre()));
            sb.append(String.format("    • Documento:  %s\n", clienteMin.getDocumento()));
            sb.append(String.format("    • Monto:      $%,.2f\n", gastoMin));
        }
        
        return sb.toString();
    }

    /**
     * Sección 4: Estadísticas de Paquetes
     */
    private String generarSeccionPaquetes() {
        StringBuilder sb = new StringBuilder();
        
        int totalNacional = gestorReservas.getTotalReservasPorTipoPaquete("nacional");
        int totalInternacional = gestorReservas.getTotalReservasPorTipoPaquete("internacional");
        int totalReservasConfirmadas = gestorReservas.getTotalReservasConfirmadas();
        
        sb.append("===============================================\n");
        sb.append("│  4. ESTADÍSTICAS DE PAQUETES TURÍSTICOS      │\n");
        sb.append("===============================================\n");
        
        sb.append("  Reservas por Tipo de Paquete:\n");
        if (totalReservasConfirmadas > 0) {
            sb.append(String.format("    ├─ Nacional:       %3d (%5.1f%%)\n",
                totalNacional, (totalNacional * 100.0) / totalReservasConfirmadas));
            sb.append(String.format("    └─ Internacional:  %3d (%5.1f%%)\n\n",
                totalInternacional, (totalInternacional * 100.0) / totalReservasConfirmadas));
        } else {
            sb.append("    └─ No hay reservas confirmadas\n\n");
        }
        
        // Mostrar información detallada de cada paquete (si están disponibles)
        sb.append("  Detalle por Paquete:\n");
        sb.append("    (Ver ocupación en el reporte de paquetes individuales)\n");
        
        return sb.toString();
    }

    /**
     * Sección 5: Estadísticas de Servicios Adicionales
     */
    private String generarSeccionServicios() {
        StringBuilder sb = new StringBuilder();
        
        double montoServicios = gestorReservas.getMontoTotalServiciosAdicionales();
        int reservasConServicios = gestorReservas.getTotalReservasConServicios();
        int totalReservas = gestorReservas.getTotalReservasConfirmadas();
        
        sb.append("================================================\n");
        sb.append("│  5. ESTADÍSTICAS DE SERVICIOS ADICIONALES    │\n");
        sb.append("================================================\n");
        
        sb.append(String.format("  • Monto Total Servicios:        $%,15.2f\n", montoServicios));
        sb.append(String.format("  • Reservas con Servicios:       %d\n", reservasConServicios));
        
        if (totalReservas > 0) {
            double porcentaje = (reservasConServicios * 100.0) / totalReservas;
            sb.append(String.format("  • Porcentaje de Reservas:       %5.1f%%\n", porcentaje));
        }
        
        return sb.toString();
    }

    /**
     * Sección 6: Estadísticas por Rango de Edad
     */
    private String generarSeccionEdades() {
        StringBuilder sb = new StringBuilder();
        
        sb.append("=======================================\n");
        sb.append("│  6. ESTADÍSTICAS POR RANGO DE EDAD  │\n");
        sb.append("=======================================\n");
        
        String[] rangos = {"Menor de 18", "18-40", "41-65", "Mayor de 65"};
        
        for (String rango : rangos) {
            EstadisticasEdad stats = calcularEstadisticasPorEdad(rango);
            sb.append(String.format("  %s:\n", rango));
            sb.append(String.format("    ├─ Clientes:  %d\n", stats.cantidadClientes));
            sb.append(String.format("    └─ Recaudado: $%,.2f\n\n", stats.montoRecaudado));
        }
        
        return sb.toString();
    }

    /**
     * Calcula estadísticas por rango de edad
     */
    private EstadisticasEdad calcularEstadisticasPorEdad(String rango) {
        EstadisticasEdad stats = new EstadisticasEdad();
        ListaEnlazada<Cliente> clientesContados = new ListaEnlazada<>();
        
        gestorReservas.getReservas().paraCadaElemento(reserva -> {
            if (!reserva.getEstado().equals("confirmada")) {
                return;
            }
            
            Cliente cliente = reserva.getCliente();
            String rangoCliente = cliente.getRangoEdad();
            
            if (rangoCliente.equals(rango)) {
                if (!clientesContados.contiene(cliente)) {
                    clientesContados.agregar(cliente);
                    stats.cantidadClientes++;
                }
                stats.montoRecaudado += reserva.getMontoTotal();
            }
        });
        
        return stats;
    }

    /**
     * Genera reporte de ocupación de paquetes
     */
    public String generarReporteOcupacionPaquetes(ListaEnlazada<PaqueteTuristico> paquetes) {
        StringBuilder sb = new StringBuilder();

        sb.append("=======================================\n");
        sb.append("│  REPORTE DE OCUPACIÓN DE PAQUETES   │\n");
        sb.append("=======================================\n\n");

        paquetes.paraCadaElemento(paquete -> {
            double montoVentas = gestorReservas.getMontoTotalPorPaquete(paquete);
            
            sb.append(String.format("Paquete: %s (%s)\n", paquete.getDestino(), paquete.getCodigo()));
            sb.append(String.format("  • Tipo:              %s\n", paquete.getTipo()));
            sb.append(String.format("  • Plazas Totales:    %d\n", paquete.getPlazasTotales()));
            sb.append(String.format("  • Plazas Ocupadas:   %d\n", paquete.getPlazasOcupadas()));
            sb.append(String.format("  • Plazas Disponibles: %d\n", paquete.getPlazasDisponibles()));
            sb.append(String.format("  • Ocupación:         %.1f%%\n", paquete.getPorcentajeOcupacion()));
            sb.append(String.format("  • Monto Recaudado:   $%,.2f\n", montoVentas));
            sb.append(String.format("  • Promedio Plazas:   %.1f\n\n", paquete.getPromedioPlazasVendidas()));
        });

        return sb.toString();
    }

    // Clase interna para estadísticas por edad
    private static class EstadisticasEdad {
        int cantidadClientes = 0;
        double montoRecaudado = 0;
    }

    // Nuevo método para reporte resumido (agregado para completitud)
    public String generarReporteResumido() {
        StringBuilder sb = new StringBuilder();
        sb.append("Resumen Ejecutivo:\n");
        sb.append(String.format("Total Reservas: %d\n", gestorReservas.getTotalReservas()));
        sb.append(String.format("Monto Total: $%,.2f\n", gestorPagos.getMontoTotalRecaudado()));
        // Agrega más según necesites
        return sb.toString();
    }
}