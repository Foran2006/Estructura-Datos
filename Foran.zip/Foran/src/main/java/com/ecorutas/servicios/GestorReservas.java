package com.ecorutas.servicios;
 // Import agregado para historialServicios
import com.ecorutas.modelos.*;
import com.ecorutas.estructuras.*;
import java.util.Date;

public class GestorReservas {
    private ListaEnlazada<Reserva> reservas;
    private ListaEnlazada<Cliente> clientes;
    private ListaEnlazada<PaqueteTuristico> paquetes;
    private Cola<String> listaEspera;
    public static Pila<String> historialServicios;
    private static int consecutivo = 1;

    public GestorReservas() {
        this.reservas = new ListaEnlazada<>();
        this.clientes = new ListaEnlazada<>();
        this.paquetes = new ListaEnlazada<>();
        this.listaEspera = new Cola<>();
    }

    public void setClientes(ListaEnlazada<Cliente> clientes) {
        this.clientes = clientes;
    }

    public void setPaquetes(ListaEnlazada<PaqueteTuristico> paquetes) {
        this.paquetes = paquetes;
    }

    public Reserva crearReserva(Cliente cliente, PaqueteTuristico paquete, 
                               int cantidadPersonas, String medioPago, Date fechaViaje) throws Exception {
        // Validar que el cliente y paquete existan en el sistema
        if (clientes.buscar(cliente) == null) {
            throw new Exception("El cliente no está registrado en el sistema");
        }
        
        if (paquetes.buscar(paquete) == null) {
            throw new Exception("El paquete no está registrado en el sistema");
        }

        // Generar código único
        String codigo = "RES" + String.format("%04d", consecutivo++);
        
        // Crear la reserva
        Reserva nuevaReserva = new Reserva(codigo, cliente, paquete, cantidadPersonas, medioPago);
        nuevaReserva.setFechaViaje(fechaViaje);
        
        // Calcular número de reservas del cliente para descuento
        int reservasCliente = contarReservasCliente(cliente);
        nuevaReserva.setNumeroReservasClienteAnio(reservasCliente);
        
        // Validar disponibilidad
        if (!paquete.tieneDisponibilidad(cantidadPersonas)) {
            // Agregar a lista de espera
            listaEspera.encolar(codigo);
            nuevaReserva.setEstado("lista_espera");
            reservas.agregar(nuevaReserva);
            throw new Exception("No hay suficientes plazas disponibles. " +
                "La reserva " + codigo + " ha sido agregada a la lista de espera.");
        }
        
        reservas.agregar(nuevaReserva);
        return nuevaReserva;
    }

    public boolean confirmarReserva(String codigoReserva) {
        Reserva reserva = buscarReserva(codigoReserva);
        if (reserva == null) {
            return false;
        }

        if (!reserva.getEstado().equals("pendiente")) {
            return false;
        }

        PaqueteTuristico paquete = reserva.getPaquete();
        if (!paquete.tieneDisponibilidad(reserva.getCantidadPersonas())) {
            // Mover a lista de espera
            listaEspera.encolar(codigoReserva);
            reserva.setEstado("lista_espera");
            return false;
        }

        // Confirmar reserva
        paquete.reservarPlazas(reserva.getCantidadPersonas());
        paquete.registrarVenta(reserva.getMontoTotal());
        reserva.setEstado("confirmada");
        
        // Incrementar contador de reservas del cliente
        reserva.getCliente().incrementarReservas();
        
        return true;
    }

    public boolean cancelarReserva(String codigoReserva) {
        Reserva reserva = buscarReserva(codigoReserva);
        if (reserva == null) {
            return false;
        }

        if (reserva.getEstado().equals("cancelada")) {
            return false;
        }

        // Si la reserva estaba confirmada, liberar plazas
        if (reserva.getEstado().equals("confirmada")) {
            PaqueteTuristico paquete = reserva.getPaquete();
            paquete.liberarPlazas(reserva.getCantidadPersonas());
            
            // Restar venta del paquete
            paquete.registrarVenta(-reserva.getMontoTotal());
        }

        // Calcular y aplicar penalidad
        double penalidad = reserva.calcularPenalidadCancelacion();
        if (penalidad > 0) {
            reserva.aplicarPenalidad(penalidad);
        }

        reserva.setEstado("cancelada");
        return true;
    }

    public void agregarServicioAdicional(String codigoReserva, ServicioAdicional servicio, int cantidadPersonas, String clienteId) throws Exception {
        Reserva reserva = buscarReserva(codigoReserva);
        if (reserva == null) {
            throw new Exception("Reserva no encontrada: " + codigoReserva);
        }
        
        if (reserva.getEstado().equals("cancelada")) {
            throw new Exception("No se pueden agregar servicios a una reserva cancelada");
        }
        
        // Manejo de capacidad
        if (!servicio.inscribir(clienteId, cantidadPersonas)) {
            throw new Exception("Cupo lleno para el servicio " + servicio.getNombre() + ". Agregado a cola de espera.");
        }
        
        reserva.agregarServicioAdicional(servicio);
        
        // Registrar en pila de servicios vendidos para análisis de demanda
        historialServicios.push(servicio.getNombre() + " - Reserva: " + codigoReserva + " - Fecha: " + new Date());
    }

    public Reserva buscarReserva(String codigo) {
        return reservas.buscarPor(r -> r.getCodigo().equals(codigo));
    }

    public ListaEnlazada<Reserva> buscarReservasPorCliente(Cliente cliente) {
        return reservas.filtrar(r -> r.getCliente().equals(cliente));
    }

    public ListaEnlazada<Reserva> buscarReservasPorPaquete(PaqueteTuristico paquete) {
        return reservas.filtrar(r -> r.getPaquete().equals(paquete));
    }

    public int contarReservasCliente(Cliente cliente) {
        return reservas.contar(r -> r.getCliente().equals(cliente) && 
                                    !r.getEstado().equals("cancelada"));
    }

    // Métodos de estadísticas
    public ListaEnlazada<Reserva> getReservas() {
        return reservas;
    }

    public int getTotalReservas() {
        return reservas.getTamanio();
    }

    public int getTotalReservasConfirmadas() {
        return reservas.contar(r -> r.getEstado().equals("confirmada"));
    }

    public int getTotalReservasPendientes() {
        return reservas.contar(r -> r.getEstado().equals("pendiente"));
    }

    public int getTotalReservasCanceladas() {
        return reservas.contar(r -> r.getEstado().equals("cancelada"));
    }

    public int getTotalReservasEnEspera() {
        return reservas.contar(r -> r.getEstado().equals("lista_espera"));
    }

    public double getMontoTotalFacturado() {
        final double[] total = {0};
        reservas.paraCadaElemento(r -> {
            if (r.getEstado().equals("confirmada")) {
                total[0] += r.getMontoTotal();
            }
        });
        return total[0];
    }

    public double getMontoTotalDescuentos() {
        final double[] total = {0};
        reservas.paraCadaElemento(r -> {
            if (r.getEstado().equals("confirmada")) {
                total[0] += r.getMontoDescuentos();
            }
        });
        return total[0];
    }

    public double getMontoTotalPorPaquete(PaqueteTuristico paquete) {
        final double[] total = {0};
        reservas.paraCadaElemento(r -> {
            if (r.getPaquete().equals(paquete) && r.getEstado().equals("confirmada")) {
                total[0] += r.getMontoTotal();
            }
        });
        return total[0];
    }

    public double getMontoTotalServiciosAdicionales() {
        final double[] total = {0};
        reservas.paraCadaElemento(r -> {
            if (r.getEstado().equals("confirmada")) {
                total[0] += r.getMontoServicios();
            }
        });
        return total[0];
    }

    public Cliente getClienteQueMasGasto() {
        if (reservas.estaVacia()) {
            return null;
        }

        Cliente[] clienteMax = {null};
        final double[] montoMax = {0};

        clientes.paraCadaElemento(cliente -> {
            double montoCliente = calcularGastoTotalCliente(cliente);
            if (montoCliente > montoMax[0]) {
                montoMax[0] = montoCliente;
                clienteMax[0] = cliente;
            }
        });

        return clienteMax[0];
    }

    public Cliente getClienteQueMenosGasto() {
        if (reservas.estaVacia()) {
            return null;
        }

        Cliente[] clienteMin = {null};
        final double[] montoMin = {Double.MAX_VALUE};

        clientes.paraCadaElemento(cliente -> {
            ListaEnlazada<Reserva> reservasCliente = buscarReservasPorCliente(cliente);
            if (!reservasCliente.estaVacia()) {
                double montoCliente = calcularGastoTotalCliente(cliente);
                if (montoCliente < montoMin[0]) {
                    montoMin[0] = montoCliente;
                    clienteMin[0] = cliente;
                }
            }
        });

        return clienteMin[0];
    }

    public double calcularGastoTotalCliente(Cliente cliente) {
        final double[] total = {0};
        reservas.paraCadaElemento(r -> {
            if (r.getCliente().equals(cliente) && r.getEstado().equals("confirmada")) {
                total[0] += r.getMontoTotal();
            }
        });
        return total[0];
    }

    public int getTotalClientesPorGenero(String genero) {
        ListaEnlazada<Cliente> clientesAtendidos = new ListaEnlazada<>();
        
        reservas.paraCadaElemento(r -> {
            if (r.getCliente().getGenero().equalsIgnoreCase(genero) && 
                !clientesAtendidos.contiene(r.getCliente())) {
                clientesAtendidos.agregar(r.getCliente());
            }
        });
        
        return clientesAtendidos.getTamanio();
    }

    public int getTotalReservasPorTipoPaquete(String tipo) {
        return reservas.contar(r -> r.getPaquete().getTipo().equalsIgnoreCase(tipo) &&
                                    r.getEstado().equals("confirmada"));
    }

    public int getTotalPersonasEnListaEspera() {
        return listaEspera.getTamanio();
    }

    public Cola<String> getListaEspera() {
        return listaEspera;
    }

    public int getTotalReservasConServicios() {
        return reservas.contar(r -> r.getServiciosAdicionales().getTamanio() > 0 &&
                                    r.getEstado().equals("confirmada"));
    }
}